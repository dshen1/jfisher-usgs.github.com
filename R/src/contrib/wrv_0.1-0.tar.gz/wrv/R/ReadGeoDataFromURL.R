ReadGeoDataFromURL <- function(u) {
  require(RCurl)

  pos <- regexpr("\\.([[:alnum:]]+)$", u)
  ext <- ifelse(pos > -1L, paste0(".", substring(u, pos + 1L)), "")

  td <- tempdir()
  tf <- file.path(td, basename(u))

  con <- CFILE(tf, mode="wb")
  certificate <- system.file("CurlSSL", "cacert.pem", package="RCurl")
  curl.options <- list(cainfo=certificate, followlocation=TRUE)
  status <- curlPerform(url=u, writedata=con@ref, .opts=curl.options)
  stopifnot(status == 0L)
  RCurl::close(con)

  # Read GeoTIFF
  if (ext == ".tif") {
    obj <- readGDAL(tf, band=1)

  # Read compressed shapefiles
  } else if (ext == ".zip") {
    unziped.files <- unzip(tf, exdir=td)
    idx <- grep("*.shp$", unziped.files)
    stopifnot(length(idx) > 0)
    lyr <- sub(".shp$", "", basename(unziped.files[idx]))
    obj <- readOGR(dsn=td, layer=lyr)
    unlink(unziped.files)
  }

  return(obj)
}

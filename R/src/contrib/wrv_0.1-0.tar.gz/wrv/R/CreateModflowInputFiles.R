CreateModflowInputFiles <- function(rs.model, id, p.run, perlen, hk, vani) {

  dir.create(path=p.run, showWarnings=FALSE)

  # List file (LST)

  ext <- ".lst"
  f <- file.path(p.run, paste0(id, ext))
  nunit <- 10L
  nam <- data.frame(ftype="LIST", nunit=nunit, fname=basename(f))

  # Basic file (BAS6)

  ext <- ".ba6"
  f <- file.path(p.run, paste0(id, ext))
  nunit <- nunit + 1L
  nam <- rbind(nam, data.frame(ftype="BAS6", nunit=nunit, fname=basename(f)))

  ds.0 <- c("#WRV----STEADY STATE", "#")
  cat(ds.0, file=f, sep="\n", append=FALSE)

  ds.1 <- "FREE"
  cat(ds.1, file=f, sep="\n", append=TRUE)

  ds.2 <- "INTERNAL 1 (FREE) 3 IBOUND layer 1"
  cat(ds.2, file=f, sep="\n", append=TRUE)
  m <- raster::as.matrix(rs.model[["lay1.ibound"]])
  m <- format(m, justify="right", width=2)
  write.table(m, file=f, append=TRUE, quote=FALSE, row.names=FALSE,
              col.names=FALSE)
  ds.2 <- "INTERNAL 1 (FREE) 3 IBOUND layer 2"
  cat(ds.2, file=f, sep="\n", append=TRUE)
  m <- raster::as.matrix(rs.model[["lay2.ibound"]])
  m <- format(m, justify="right", width=2)
  write.table(m, file=f, append=TRUE, quote=FALSE, row.names=FALSE,
              col.names=FALSE)
  ds.2 <- "INTERNAL 1 (FREE) 3 IBOUND layer 3"
  cat(ds.2, file=f, sep="\n", append=TRUE)
  m <- raster::as.matrix(rs.model[["lay3.ibound"]])
  m <- format(m, justify="right", width=2)
  write.table(m, file=f, append=TRUE, quote=FALSE, row.names=FALSE,
              col.names=FALSE)

  hnoflo <- 0.0
  ds.3 <- paste(hnoflo, "HNOFLO")
  cat(ds.3, file=f, sep="\n", append=TRUE)

  ds.4 <- "INTERNAL 1 (FREE) 3 Initial Head layer 1"
  cat(ds.4, file=f, sep="\n", append=TRUE)
  m <- raster::as.matrix(rs.model[["lay1.strt"]])
  m[is.na(m)] <- hnoflo
  write.table(m, file=f, append=TRUE, quote=FALSE, row.names=FALSE,
              col.names=FALSE)
  ds.4 <- "INTERNAL 1 (FREE) 3 Initial Head layer 2"
  cat(ds.4, file=f, sep="\n", append=TRUE)
  m <- raster::as.matrix(rs.model[["lay2.strt"]])
  m[is.na(m)] <- hnoflo
  write.table(m, file=f, append=TRUE, quote=FALSE, row.names=FALSE,
              col.names=FALSE)
  ds.4 <- "INTERNAL 1 (FREE) 3 Initial Head layer 3"
  cat(ds.4, file=f, sep="\n", append=TRUE)
  m <- raster::as.matrix(rs.model[["lay3.strt"]])
  m[is.na(m)] <- hnoflo
  write.table(m, file=f, append=TRUE, quote=FALSE, row.names=FALSE,
              col.names=FALSE)

  # Discretization file (DIS)

  ext <- ".dis"
  f <- file.path(p.run, paste0(id, ext))
  nunit <- nunit + 1L
  nam <- rbind(nam, data.frame(ftype="DIS", nunit=nunit, fname=basename(f)))

  cat(ds.0, file=f, sep="\n", append=FALSE)

  ds.1 <- paste(3L, nrow(rs.model), ncol(rs.model), 1L, 4L, 2L,  # days, meters
                "NLAY,NROW,NCOL,NPER,ITMUNI,LENUNI")
  cat(ds.1, file=f, sep="\n", append=TRUE)

  ds.2 <- paste(rep(0, 3), collapse=" ")  # LAYCBD
  cat(ds.2, file=f, sep="\n", append=TRUE)

  ds.3 <- paste("CONSTANT", res(rs.model)[2], "DELR")
  cat(ds.3, file=f, sep="\n", append=TRUE)

  ds.4 <- paste("CONSTANT", res(rs.model)[1], "DELC")
  cat(ds.4, file=f, sep="\n", append=TRUE)

  ds.5 <- "INTERNAL 1 (FREE) 3 TOP layer 1"
  cat(ds.5, file=f, sep="\n", append=TRUE)
  m <- raster::as.matrix(rs.model[["lay1.top"]])
  m[is.na(m)] <- 0.0
  write.table(m, file=f, append=TRUE, quote=FALSE, row.names=FALSE,
              col.names=FALSE)

  ds.6 <-"INTERNAL 1 (FREE) 3 BOTM layer 1"
  cat(ds.6, file=f, sep="\n", append=TRUE)
  m <- raster::as.matrix(rs.model[["lay1.bottom"]])
  m[is.na(m)] <- 0.0
  write.table(m, file=f, append=TRUE, quote=FALSE, row.names=FALSE,
              col.names=FALSE)
  ds.6 <- "INTERNAL 1 (FREE) 3 BOTM layer 2"
  cat(ds.6, file=f, sep="\n", append=TRUE)
  m <- raster::as.matrix(rs.model[["lay2.bottom"]])
  m[is.na(m)] <- 0.0
  write.table(m, file=f, append=TRUE, quote=FALSE, row.names=FALSE,
              col.names=FALSE)
  ds.6 <- "INTERNAL 1 (FREE) 3 BOTM layer 3"
  cat(ds.6, file=f, sep="\n", append=TRUE)
  m <- raster::as.matrix(rs.model[["lay3.bottom"]])
  m[is.na(m)] <- 0.0
  write.table(m, file=f, append=TRUE, quote=FALSE, row.names=FALSE,
              col.names=FALSE)

  ds.7 <- paste(perlen, 1, 1, "SS", "PERLEN,NSTP,TSMULT,Ss/tr")
  cat(ds.7, file=f, sep="\n", append=TRUE)

  # Zone file (ZONE)

  ext <- ".zon"
  f <- file.path(p.run, paste0(id, ext))
  nunit <- nunit + 1L
  nam <- rbind(nam, data.frame(ftype="ZONE", nunit=nunit, fname=basename(f)))

  cat(ds.0, file=f, sep="\n", append=FALSE)

  ds.1 <- 3  # NZN
  cat(ds.1, file=f, sep="\n", append=TRUE)

  ds.2 <- "LAY1ZONES"
  cat(ds.2, file=f, sep="\n", append=TRUE)
  ds.3 <- "INTERNAL 1 (FREE) 3 ZONE layer 1"
  cat(ds.3, file=f, sep="\n", append=TRUE)
  m <- raster::as.matrix(rs.model[["lay1.zones"]])
  m[is.na(m)] <- 0
  write.table(m, file=f, append=TRUE, quote=FALSE, row.names=FALSE,
              col.names=FALSE)

  ds.2 <- "LAY2ZONES"
  cat(ds.2, file=f, sep="\n", append=TRUE)
  ds.3 <- "INTERNAL 1 (FREE) 3 ZONE layer 2"
  cat(ds.3, file=f, sep="\n", append=TRUE)
  m <- raster::as.matrix(rs.model[["lay2.zones"]])
  m[is.na(m)] <- 0
  write.table(m, file=f, append=TRUE, quote=FALSE, row.names=FALSE,
              col.names=FALSE)

  ds.2 <- "LAY3ZONES"
  cat(ds.2, file=f, sep="\n", append=TRUE)
  ds.3 <- "INTERNAL 1 (FREE) 3 ZONE layer 3"
  cat(ds.3, file=f, sep="\n", append=TRUE)
  m <- raster::as.matrix(rs.model[["lay3.zones"]])
  m[is.na(m)] <- 0
  write.table(m, file=f, append=TRUE, quote=FALSE, row.names=FALSE,
              col.names=FALSE)

  # Layer-Property Flow file (LPF)

  ext <- ".lpf"
  f <- file.path(p.run, paste0(id, ext))
  nunit <- nunit + 1L
  nam <- rbind(nam, data.frame(ftype="LPF", nunit=nunit, fname=basename(f)))

  cat(ds.0, file=f, sep="\n", append=FALSE)

  ds.1 <- paste(-1, 1e30, 6, "CONSTANTCV", "NOVFC", "ILPFCB,HDRY,NPLPF,[Options]")
  cat(ds.1, file=f, sep="\n", append=TRUE)

  ds.2 <- paste(4, 0, 0, "LAYTYP")  # 0 confined, >0 convertible, <0 see THICKSTRT
  cat(ds.2, file=f, sep="\n", append=TRUE)

  ds.3 <- paste(0, 0, 0, "LAYAVG")  # 0 harmonic mean (abrupt boundaries in T)
  cat(ds.3, file=f, sep="\n", append=TRUE)

  ds.4 <- paste(1, 1, 1, "CHANI")  # horiz anisotropy is 1
  cat(ds.4, file=f, sep="\n", append=TRUE)

  ds.5 <- paste(0, 0, 0, "LAYKA")  # VKA is the vert hydraulic conductivity
  cat(ds.5, file=f, sep="\n", append=TRUE)

  ds.6 <- paste(0, 0, 0, "LAYWET")  # 0 indicates wetting is inactive, not 0 is active
  cat(ds.6, file=f, sep="\n", append=TRUE)

  ds.8 <- paste("HKA HK", hk[1], "3")
  cat(ds.8, file=f, sep="\n", append=TRUE)
  ds.9 <- paste(1, "NONE", "LAY1ZONES", 1)
  cat(ds.9, file=f, sep="\n", append=TRUE)
  ds.9 <- paste(2, "NONE", "LAY2ZONES", 1)
  cat(ds.9, file=f, sep="\n", append=TRUE)
  ds.9 <- paste(3, "NONE", "LAY3ZONES", 1)
  cat(ds.9, file=f, sep="\n", append=TRUE)

  ds.8 <- paste("HKB HK", hk[2], "2")
  cat(ds.8, file=f, sep="\n", append=TRUE)
  ds.9 <- paste(2, "NONE", "LAY2ZONES", 2)
  cat(ds.9, file=f, sep="\n", append=TRUE)
  ds.9 <- paste(3, "NONE", "LAY3ZONES", 2)
  cat(ds.9, file=f, sep="\n", append=TRUE)

  ds.8 <- paste("HKC HK", hk[3], "1")
  cat(ds.8, file=f, sep="\n", append=TRUE)
  ds.9 <- paste(2, "NONE", "LAY2ZONES", 3)
  cat(ds.9, file=f, sep="\n", append=TRUE)

  vk <- hk / vani
  ds.8 <- paste("VKA VK", vk[1], "3")
  cat(ds.8, file=f, sep="\n", append=TRUE)
  ds.9 <- paste(1, "NONE", "LAY1ZONES", 1)
  cat(ds.9, file=f, sep="\n", append=TRUE)
  ds.9 <- paste(2, "NONE", "LAY2ZONES", 1)
  cat(ds.9, file=f, sep="\n", append=TRUE)
  ds.9 <- paste(3, "NONE", "LAY3ZONES", 1)
  cat(ds.9, file=f, sep="\n", append=TRUE)

  ds.8 <- paste("VKB VK", vk[2], "2")
  cat(ds.8, file=f, sep="\n", append=TRUE)
  ds.9 <- paste(2, "NONE", "LAY2ZONES", 2)
  cat(ds.9, file=f, sep="\n", append=TRUE)
  ds.9 <- paste(3, "NONE", "LAY3ZONES", 2)
  cat(ds.9, file=f, sep="\n", append=TRUE)

  ds.8 <- paste("VKC VK", vk[3], "1")
  cat(ds.8, file=f, sep="\n", append=TRUE)
  ds.9 <- paste(2, "NONE", "LAY2ZONES", 3)
  cat(ds.9, file=f, sep="\n", append=TRUE)


  ds.10 <- 0 # Print code, HK layer 1
  cat(ds.10, file=f, sep="\n", append=TRUE)
  ds.12 <- 0 # Print code, VK layer 1
  cat(ds.12, file=f, sep="\n", append=TRUE)

  ds.10 <- 0 # Print code, HK layer 2
  cat(ds.10, file=f, sep="\n", append=TRUE)
  ds.12 <- 0 # Print code, VK layer 2
  cat(ds.12, file=f, sep="\n", append=TRUE)

  ds.10 <- 0 # Print code, HK layer 3
  cat(ds.10, file=f, sep="\n", append=TRUE)
  ds.12 <- 0 # Print code, VK layer 3
  cat(ds.12, file=f, sep="\n", append=TRUE)

  # Flow and Head Boundary file (FHB)

  ext <- ".fhb"
  f <- file.path(p.run, paste0(id, ext))
  nunit <- nunit + 1L
  nam <- rbind(nam, data.frame(ftype="FHB", nunit=nunit, fname=basename(f)))

  r <- rs.model[["lay1.bdry.sources"]]
  cells <- which(!is.na(r[]))
  rc <- rowColFromCell(r, cells)

  ds.1 <- paste(1, length(cells), 0, 0, 0, 0, 0,
                "NBDTIM,NFLW,NHED,IFHBSS,IFHBCB,NFHBX1,NFHBX2")
  cat(ds.1, file=f, sep="\n", append=FALSE)

  ds.4a <- paste(nunit, 1.0, 1, "IFHBUN,CNSTM,IFHBPT")
  cat(ds.4a, file=f, sep="\n", append=TRUE)
  ds.4b <- paste(0.0, "BDTIM")
  cat(ds.4b, file=f, sep="\n", append=TRUE)

  ds.5a <- paste(nunit, 1.0, 1, "IFHBUN,CNSTM,IFHBPT")
  cat(ds.5a, file=f, sep="\n", append=TRUE)
  ds.5b <- cbind(lay=1, rowColFromCell(r, cells), iaux=0, flow=r[cells])
  write.table(ds.5b, file=f, append=TRUE, quote=FALSE, row.names=FALSE,
              col.names=FALSE)

  # Drain file (DRN)

  ext <- ".drn"
  f <- file.path(p.run, paste0(id, ext))
  nunit <- nunit + 1L
  nam <- rbind(nam, data.frame(ftype="DRN", nunit=nunit, fname=basename(f)))

  cat(ds.0, file=f, sep="\n", append=FALSE)

  r1 <- rs.model[["lay1.bdry.sinks"]]
  r2 <- rs.model[["lay2.bdry.sinks"]]
  r3 <- rs.model[["lay3.bdry.sinks"]]

  c1 <- which(!is.na(r1[]))
  c2 <- which(!is.na(r2[]))
  c3 <- which(!is.na(r3[]))

  hk1 <- hk[rs.model[["lay1.zones"]][c1]]
  hk2 <- hk[rs.model[["lay2.zones"]][c2]]
  hk3 <- hk[rs.model[["lay3.zones"]][c3]]

  dz1 <- rs.model[["lay1.thickness"]][c1]
  dz2 <- rs.model[["lay2.thickness"]][c2]
  dz3 <- rs.model[["lay3.thickness"]][c3]

  r1 <- cbind(lay=1, rowColFromCell(r1, c1), elev=r1[c1], cond=hk1 * dz1)
  r2 <- cbind(lay=2, rowColFromCell(r2, c2), elev=r2[c2], cond=hk2 * dz2)
  r3 <- cbind(lay=3, rowColFromCell(r3, c3), elev=r3[c3], cond=hk3 * dz3)

  ds.6 <- rbind(r1, r2, r3)

  ds.2 <- paste(nrow(ds.6), -1, "MXACTD,IDRNCB")
  cat(ds.2, file=f, sep="\n", append=TRUE)

  ds.5 <- paste(nrow(ds.6), 0, "ITMP,NP")
  cat(ds.5, file=f, sep="\n", append=TRUE)

  write.table(ds.6, file=f, append=TRUE, quote=FALSE, row.names=FALSE,
              col.names=FALSE)

  # Sparse Matrix Solver file (SMS)

  ext <- ".sms"
  f <- file.path(p.run, paste0(id, ext))
  nunit <- nunit + 1L
  nam <- rbind(nam, data.frame(ftype="SMS", nunit=nunit, fname=basename(f)))

  cat(ds.0, file=f, sep="\n", append=FALSE)

  ds.1 <- paste("COMPLEX", "OPTIONS")
  cat(ds.1, file=f, sep="\n", append=TRUE)

  ds.2 <- paste(0.01, 0.01, 100, 100, 1, 1, 1,
                "HCLOSE,HICLOSE,MXITER,ITER1,IPRSMS,NONLINMETH,LINMETH")
  cat(ds.2, file=f, sep="\n", append=TRUE)

  # Output control (OC)

  ext <- ".oc"
  f <- file.path(p.run, paste0(id, ext))
  nunit <- nunit + 1L
  nam <- rbind(nam, data.frame(ftype="OC", nunit=nunit, fname=basename(f)))

  cat(ds.0, file=f, sep="\n", append=FALSE)

  ds.1 <- NULL

  ext <- ".hds"
  nunit <- nunit + 1L
  nam <- rbind(nam, data.frame(ftype="DATA(BINARY)", nunit=nunit,
                               fname=paste0(id, ext)))
  ds.1[1] <- paste("HEAD SAVE UNIT", nunit)
  ds.1[2] <- paste("HEAD PRINT FORMAT", 0)

  ext <- ".ddn"
  nunit <- nunit + 1L
  nam <- rbind(nam, data.frame(ftype="DATA(BINARY)", nunit=nunit,
                               fname=paste0(id, ext)))
  ds.1[3] <- paste("DRAWDOWN SAVE UNIT", nunit)
  ds.1[4] <- paste("DRAWDOWN PRINT FORMAT", 0)

  cat(ds.1, file=f, sep="\n", append=TRUE)

  ds.2 <- paste("PERIOD", 1, "STEP", 1)
  cat(ds.2, file=f, sep="\n", append=TRUE)

  ds.3 <- NULL
  ds.3[1] <- "SAVE HEAD"
  ds.3[2] <- "SAVE DRAWDOWN"
  ds.3[3] <- "SAVE BUDGET"
  ds.3 <- paste("    ", ds.3)
  cat(ds.3, file=f, sep="\n", append=TRUE)

  # Name file
  ext <- ".nam"
  f <- file.path(p.run, paste0(id, ext))
  write.table(nam, file=f, append=FALSE, quote=FALSE, sep=" ",
              row.names=FALSE, col.names=FALSE)

}

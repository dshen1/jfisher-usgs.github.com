

.GetSurroundingCells <- function(r, cell) {
  row.col <- rowColFromCell(r, cell)
  i <- row.col[1, "row"]
  j <- row.col[1, "col"]
  ij <- rbind(c(i + 1, j + 0),
              c(i + 0, j - 1),
              c(i - 1, j + 0),
              c(i + 0, j + 1))
  adj.cells <- as.integer(cellFromRowCol(r, ij[, 1], ij[, 2]))
  adj.cells <- vapply(adj.cells,
                      function(i) ifelse(!is.na(i) && is.na(r[i]), NA, i), 1L)
  return(adj.cells)
}


FindConnectedCells <- function(r.bot, r.top, min.overlap) {
  cells <- which(!is.na(values(r.bot)))
  ntimes <- r.bot
  values(ntimes) <- rep(0L, length(ntimes))

  fun <- function(i) {
    adj.cells <- na.omit(.GetSurroundingCells(r.bot, i))
    for (j in adj.cells) {
      if (r.top[i] <= r.bot[j] + min.overlap ||
          r.bot[i] >= r.top[j] - min.overlap)
        ntimes[i] <<- ntimes[i] + 1L
    }
  }
  apply(as.matrix(cells), 1L, fun)

  max.ntimes <- max(values(ntimes), na.rm=TRUE)
  if (max.ntimes > 0) {
    rm.cells <- which(values(ntimes) == max.ntimes)
    r.bot[rm.cells] <- NA
    r.top[rm.cells] <- NA
    if (max.ntimes > 1) {
      for (k in (max.ntimes - 1L):1L) {
        cells <- which(values(ntimes) > 0L & values(ntimes) < k + 1L)
        values(ntimes) <- rep(0L, length(ntimes))
        apply(as.matrix(cells), 1L, fun)
        rm.cells <- c(rm.cells, which(values(ntimes) == k))
        r.bot[rm.cells] <- NA
        r.top[rm.cells] <- NA
      }
    }
  }

  r <- r.bot
  values(r) <- rep(NA, length(r))
  r[which(!is.na(values(r.bot)))] <- 1L
  r[rm.cells] <- 0L
  return(r)
}

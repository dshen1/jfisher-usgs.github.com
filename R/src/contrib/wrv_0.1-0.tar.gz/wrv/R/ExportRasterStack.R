ExportRasterStack <- function(p, rs, NAflag=-999) {

  dir.create(path=p, showWarnings=FALSE)
  p.dat <- file.path(p, "Text")
  dir.create(path=p.dat, showWarnings=FALSE)
  p.png <- file.path(p, "PNG")
  dir.create(path=p.png, showWarnings=FALSE)
  p.tif <- file.path(p, "GeoTIFF")
  dir.create(path=p.tif, showWarnings=FALSE)

  n <- 0L

  for (i in names(rs)) {
    n <- n + 1L
    fig.num <- formatC(n, width=2, format="d", flag="0")

    f <- file.path(p.dat, paste(fig.num, "_", i, ".dat", sep=""))
    m <- matrix(data=values(rs[[i]]), nrow=nrow(rs), ncol=ncol(rs), byrow=TRUE)
    write.table(m, file=f, quote=FALSE, na="0",
                row.names=FALSE, col.names=FALSE)

    f <- file.path(p.png, paste(fig.num, "_", i, ".png", sep=""))
    png(filename=f, width=7, height=7, units="in", pointsize=12, res=1200,
        antialias="cleartype")
    plot(rs[[i]], maxpixels=length(rs[[i]]), main=names(rs[[i]]), asp=1)
    dev.off()

    f <- file.path(p.tif, paste(fig.num, "_", i, ".tif", sep=""))
    writeRaster(rs[[i]], filename=f, format="GTiff", overwrite=TRUE,
                NAflag=NAflag)
  }

  f <- file.path(p, "raster.stack.rda")
  save(rs, file=f)
}

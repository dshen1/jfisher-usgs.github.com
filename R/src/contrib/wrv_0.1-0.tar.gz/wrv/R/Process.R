.Process <- function() {


  fact <- 5L

  r <- aggregate(raster(alluvium.bottom), fact)
  names(r) <- "alluvium.bottom"

  rs <- r

  xlim <- c(xmin(r), xmax(r))
  ylim <- c(ymin(r), ymax(r))

  ###

  r <- aggregate(raster(land.surface), fact)
  names(r) <- "land.surface"
  rs <- stack(rs, r)

  ###

  r <- rs[["land.surface"]] - rs[["alluvium.bottom"]]
  names(r) <- "alluvium.thickness"
  rs <- stack(rs, r)

  ###

  min.coverage <- 1L  # minimum percentage of each cell that is covered by the polygon (1-100)

  r <- rasterize(aquitard.extent, rs, getCover=TRUE, silent=TRUE)
  r[r < min.coverage] <- NA
  names(r) <- "aquitard.extent"
  rs <- stack(rs, r)

  r <- rasterize(basalt.extent, rs, getCover=TRUE, silent=TRUE)
  r[r < min.coverage] <- NA
  names(r) <- "basalt.extent"
  rs <- stack(rs, r)

  ###

  depth.to.aquitard.top <- 30 # in meters (about 100 ft)

  r <- rs[["land.surface"]] - depth.to.aquitard.top
  r[r < rs[["alluvium.bottom"]] | is.na(rs[["aquitard.extent"]])] <- NA
  names(r) <- "aquitard.top"
  rs <- stack(rs, r)

  depth.to.basalt.bottom <- 52 # in meters (about 170 ft)

  r <- rs[["land.surface"]] - depth.to.basalt.bottom
  r[r > rs[["alluvium.bottom"]] | is.na(rs[["basalt.extent"]])] <- NA
  names(r) <- "basalt.bottom"
  rs <- stack(rs, r)

  r <- rs[["alluvium.bottom"]]
  is.valid <- !is.na(rs[["basalt.bottom"]])
  r[is.valid] <- rs[["basalt.bottom"]][is.valid]
  names(r) <- "bedrock"
  rs <- stack(rs, r)

  ###

  min.overlap <- 2.0  # in meters, minimum vertical overlap between adjacent cells

  r <- FindConnectedCells(rs[["bedrock"]], rs[["land.surface"]], min.overlap)
  names(r) <- "is.connected"
  rs <- stack(rs, r)

  ###

  l <- gIntersection(as(source.locations, "SpatialLinesDataFrame"),
                     aquifer.extent, byid=TRUE)
  source.lines <- SpatialLinesDataFrame(l, data=source.locations@data,
                                        match.ID=FALSE)

  r <- rs[["alluvium.bottom"]]
  is.in.aquifer <- !is.na(r)
  is.in.poly <- !is.na(rasterize(source.locations, rs))
  is.on.line <- !is.na(rasterize(source.lines, rs))
  r[is.in.aquifer &  is.in.poly] <- 0L
  r[is.in.aquifer & !is.in.poly] <- 1L
  r[is.in.aquifer &  is.on.line] <- 2L
  names(r) <- "is.below.src"
  rs <- stack(rs, r)

  ###

  l <- gIntersection(sink.locations, as(aquifer.extent, "SpatialLinesDataFrame"),
                     byid=TRUE)
  sink.lines <- SpatialLinesDataFrame(l, data=sink.locations@data,
                                      match.ID=FALSE)

  ###

  min.thickness <- 1.0 # in meters, minimum vertical thickness of a cell

  r <- rs[["land.surface"]] - depth.to.aquitard.top
  r[is.na(rs[["alluvium.bottom"]])] <- NA
  is.valid <- rs[["alluvium.bottom"]] > r
  r[is.valid] <- rs[["alluvium.bottom"]][is.valid]
  r[(rs[["land.surface"]] - r) < min.thickness] <- NA
  if ("is.connected" %in% names(rs))
    r[rs[["is.connected"]] == 0L] <- NA
  if ("is.below.src" %in% names(rs))
    r[rs[["is.below.src"]] == 0L] <- NA
  r <- ExcludeSmallCellChunks(r)
  names(r) <- "lay1.bottom"
  rs.model <- r

  aquitard.thickness <- 5.0 # in meters (about 16 ft)

  r <- rs.model[["lay1.bottom"]] - aquitard.thickness
  is.valid <- rs[["bedrock"]] > r
  r[is.valid] <- rs[["bedrock"]][is.valid]
  r[(rs.model[["lay1.bottom"]] - r) < min.thickness] <- NA
  r <- ExcludeSmallCellChunks(r)
  names(r) <- "lay2.bottom"
  rs.model <- stack(rs.model, r)

  r <- rs[["bedrock"]]
  r[is.na(rs.model[["lay2.bottom"]])] <- NA
  r[(rs.model[["lay2.bottom"]] - r) < min.thickness] <- NA
  r <- ExcludeSmallCellChunks(r)
  names(r) <- "lay3.bottom"
  rs.model <- stack(rs.model, r)

  r <- rs.model[["lay1.bottom"]]
  is.valid <- r > rs[["bedrock"]] & is.na(rs.model[["lay2.bottom"]])
  r[is.valid] <- rs[["bedrock"]][is.valid]
  r <- ExcludeSmallCellChunks(r)
  rs.model[["lay1.bottom"]] <- r

  r <- rs[["land.surface"]]
  r[is.na(rs.model[["lay1.bottom"]])] <- NA
  names(r) <- "lay1.top"
  rs.model <- stack(rs.model, r)

  ###

  r <- rs[["land.surface"]] - rs.model[["lay1.bottom"]]
  names(r) <- "lay1.thickness"
  rs.model <- stack(rs.model, r)

  r <- rs.model[["lay1.bottom"]] - rs.model[["lay2.bottom"]]
  names(r) <- "lay2.thickness"
  rs.model <- stack(rs.model, r)

  r <- rs.model[["lay2.bottom"]] - rs.model[["lay3.bottom"]]
  names(r) <- "lay3.thickness"
  rs.model <- stack(rs.model, r)

  r <- rs[["land.surface"]] - rs[["bedrock"]]
  r[is.na(rs.model[["lay1.bottom"]])] <- NA
  names(r) <- "model.thickness"
  rs.model <- stack(rs.model, r)

  ###

  r <- rs.model[["lay1.bottom"]]
  r[!is.na(r)] <- 1L
  names(r) <- "lay1.zones"
  rs.model <- stack(rs.model, r)

  r <- rs.model[["lay2.bottom"]]
  r[!is.na(r)] <- 1L
  r[!is.na(r) & !is.na(rs[["aquitard.extent"]])] <- 3L
  r[rs.model[["lay2.bottom"]] < rs[["alluvium.bottom"]]] <- 2L
  names(r) <- "lay2.zones"
  rs.model <- stack(rs.model, r)

  r <- rs.model[["lay3.bottom"]]
  r[!is.na(r)] <- 1L
  r[rs.model[["lay3.bottom"]] < rs[["alluvium.bottom"]]] <- 2L
  names(r) <- "lay3.zones"
  rs.model <- stack(rs.model, r)

  ###

  r <- rs.model[[1]]
  r[] <- NA
  ras <- rasterize(source.lines, r)
  rat <- levels(ras)[[1]]
  is.active <- !is.na(rs.model[["lay1.bottom"]][])



# check this



  for (i in 1:nrow(rat)) {
    idxs <- which(ras[] == rat$ID[i] & is.active)
    r[idxs] <- rat$Flow[i] / length(idxs)
  }
  names(r) <- "lay1.bdry.sources"
  rs.model <- stack(rs.model, r)

  ###

  r <- rasterize(sink.lines, rs.model, field="Head")
  r[!is.na(r) & is.na(rs.model[["lay1.bottom"]])] <- NA
  names(r) <- "lay1.bdry.sinks"
  rs.model <- stack(rs.model, r)

  r <- rasterize(sink.lines, rs.model, field="Head")
  r[!is.na(r) & is.na(rs.model[["lay2.bottom"]])] <- NA
  names(r) <- "lay2.bdry.sinks"
  rs.model <- stack(rs.model, r)

  r <- rasterize(sink.lines, rs.model, field="Head")
  r[!is.na(r) & is.na(rs.model[["lay3.bottom"]])] <- NA
  names(r) <- "lay3.bdry.sinks"
  rs.model <- stack(rs.model, r)

  ###

  rs.model <- crop(rs.model, trim(rs.model[["lay1.bottom"]]))

  nams <- c("Number of Rows", "Number of Columns", "Uniform X Spacing",
            "Uniform Y Spacing", "World Coordinates of Model Origin X",
            "World Coordinates of Model Origin Y")
  vals <- c(nrow(rs.model), ncol(rs.model), res(rs.model), xmin(rs.model),
            ymin(rs.model))
  print(as.data.frame(vals, row.names=nams))

  ###

  r <- rs.model[["lay1.bottom"]]
  values(r) <- as.integer(!is.na(values(r)))
  names(r) <- "lay1.ibound"
  rs.model <- stack(rs.model, r)

  r <- rs.model[["lay2.bottom"]]
  values(r) <-  as.integer(!is.na(values(r)))
  names(r) <- "lay2.ibound"
  rs.model <- stack(rs.model, r)

  r <- rs.model[["lay3.bottom"]]
  values(r) <-  as.integer(!is.na(values(r)))
  names(r) <- "lay3.ibound"
  rs.model <- stack(rs.model, r)

  initial.head.frac <- 0.90  # initial head, fraction of layer 1 thickness saturated

  r <- rs.model[["lay1.bottom"]] +
       rs.model[["lay1.thickness"]] * initial.head.frac
  names(r) <- "lay1.strt"
  rs.model <- stack(rs.model, r)

  r <- rs.model[["lay1.strt"]]
  r[is.na(rs.model[["lay2.bottom"]])] <- NA
  names(r) <- "lay2.strt"
  rs.model <- stack(rs.model, r)

  r <- rs.model[["lay1.strt"]]
  r[is.na(rs.model[["lay3.bottom"]])] <- NA
  names(r) <- "lay3.strt"
  rs.model <- stack(rs.model, r)

  ###

  p <- getwd()  # path name for raster export and model run

  p.out <- file.path(p, format(Sys.time(), "%Y%m%d%H%M%S"))
  dir.create(path=p.out)
  ExportRasterStack(file.path(p.out, "Data"), rs)
  ExportRasterStack(file.path(p.out, "Model"), rs.model)

  ###

  id <- "wrv_ss_mfusg"  # name of model run
  perlen <- 5479  # in days, period length
  hk <- c(30.48, 86.4, 8.64e-7)  # in m/d, horiz. K of alluvium, basalt, clay
  vani <- 1000  # vertical anisotropy

  p.run <- file.path(p.out, "Run")
  CreateModflowInputFiles(rs.model, id, p.run, perlen, hk, vani)

  ###

  if (.Platform$OS.type == "windows") {

    p.model <- "C:/WRDAPP/mfusg.1_1/bin/mfusg_x64.exe"  # path to model executable

    f <- file.path(p.run, "Run.bat")
    cmd <- NULL
    cmd <- append(cmd, paste0(p.model, " ", id, ".nam"))
    cmd <- paste(Sys.getenv("COMSPEC"), "/c", cmd)
    cat(c(paste("CD", "/d", p.run), cmd), file=f, sep="\n")
    system(shQuote(f))
  }

  ###

  f <- file.path(p.run, paste0(id, ".hds"))
  r <- rs.model[[1]]
  rs.heads <- ReadModflowBinaryFile(f, r)

  r <- rs.heads[[1]] > rs.model[["lay1.top"]] & rs.heads[[1]] < 1e30
  names(r) <- "lay1.saturated"
  rs.heads <- stack(rs.heads, r)

  r <- rs.heads[[1]] >= 1e30
  names(r) <- "lay1.dry"
  rs.heads <- stack(rs.heads, r)

  r <- rs.heads[["ts1.sp1.lay1"]]
  cells <- which(values(r) >= 1e30)
  if (length(cells) > 0) {
    r[cells] <- NA
    names(r) <- "ts1.sp1.lay1.rmdry"
    rs.heads <- stack(rs.heads, r)
  }

  ExportRasterStack(p.run, rs.heads)

}

ExtractAlongTransect <- function(r, v, rtn.polygon=FALSE) {

  if (!inherits(r, c("RasterLayer", "RasterStack")))
    stop("incorrect class of raster")
  if (!inherits(v, "SpatialPoints") || length(v) < 2)
    stop("incorrect class or structure for verticies")

  if (inherits(r, "RasterLayer")) {
    r1 <- r
    r2 <- NULL
  } else {
    r1 <- r[[1]]
    r2 <- if (nlayers(r) > 1L) r[[2]] else NULL
  }

  crs <- CRS(proj4string(r1))
  v <- coordinates(spTransform(v, crs))

  rx <- seq(xmin(r1), xmax(r1), by=xres(r1))
  ry <- seq(ymin(r1), ymax(r1), by=yres(r1))

  segs <- list()
  mat.d <- as.matrix(dist(v))

  v.d <- 0

  for (i in 1:(nrow(v) - 1L)) {

    v.x <- v[i:(i + 1), 1]
    v.y <- v[i:(i + 1), 2]

    m <- (v.y[2] - v.y[1]) / (v.x[2] - v.x[1])
    rx.x <- rx[rx > min(v.x) & rx < max(v.x)]
    ry.y <- ry[ry > min(v.y) & ry < max(v.y)]
    rx.y <- m * (rx.x - v.x[1]) + v.y[1]
    ry.x <- (ry.y - v.y[1]) / m + v.x[1]

    x <- c(v.x[1], rx.x, ry.x, v.x[2])
    y <- c(v.y[1], rx.y, ry.y, v.y[2])

    d <- as.matrix(dist(cbind(x, y), diag=TRUE))[, 1]
    idxs <- order(d)
    x <- x[idxs]
    y <- y[idxs]
    d <- d[idxs]
    idxs <- which(x >= xmin(r1) & x <= xmax(r1) & y >= ymin(r1) & y <= ymax(r1))
    x <- x[idxs]
    y <- y[idxs]
    d <- d[idxs] + sum(v.d)
    n <- length(d)
    mid.x <- vapply(1:(n - 1), function(j) mean(c(x[j], x[j + 1])), 0)
    mid.y <- vapply(1:(n - 1), function(j) mean(c(y[j], y[j + 1])), 0)

    x <- c(x[1], rep(x[2:(n - 1)], each=2), x[n])
    y <- c(y[1], rep(y[2:(n - 1)], each=2), y[n])
    d <- c(d[1], rep(d[2:(n - 1)], each=2), d[n])

    z1 <- rep(extract(r1, SpatialPoints(cbind(mid.x, mid.y))), each=2)
    if (is.null(r2)) {
      z2 <- NULL
      is.z.na <- is.na(z1)
    } else {
      z2 <- rep(extract(r2, SpatialPoints(cbind(mid.x, mid.y))), each=2)
      is.z.na <- is.na(z1) | is.na(z2)
    }
    if (all(is.z.na))
      next

    seg <- cbind(x, y, d, z1, z2)
    rownames(seg) <- 1:nrow(seg)

    idxs <- NULL
    n <- nrow(seg)
    for (j in 1:n) {
      is.last.z <- j == n
      if (is.na(z1[j]) || is.last.z || (!is.null(z2[j]) && is.na(z2[j]))) {
        if (is.null(idxs))
          next
        if (is.last.z)
          idxs <- c(idxs, j)
        nsegs <- length(segs)
        if (nsegs == 0 || max(segs[[nsegs]][, "d"]) != min(d[idxs]))
          segs[[nsegs + 1]] <- seg[idxs, ]
        else
          segs[[nsegs]] <- rbind(segs[[nsegs]], seg[idxs, ])
        idxs <- NULL
      } else {
        idxs <- c(idxs, j)
      }
    }
    v.d <- c(v.d, mat.d[i, i + 1])
  }

  if (!is.null(r2) && rtn.polygon) {
    .BuildPolygon <- function(s) {
      rbind(s[, c("d", "z1")], s[nrow(s):1, c("d", "z2")], s[1, c("d", "z1")])
    }
    xy <- lapply(segs, .BuildPolygon)
    plys <- lapply(xy, function(i) as(i, "gpc.poly"))
    ply <- plys[[1]]
    if (length(plys) > 1) {
      for (i in 2:length(plys))
        ply <- append.poly(ply, plys[[i]])
    }
    return(ply)
  } else {
    segs <- lapply(segs, function(seg) {
              SpatialPointsDataFrame(coords=seg[, 1:2],
                                     data=as.data.frame(seg[, -(1:2)]),
                                     proj4string=crs, match.ID=FALSE)})
    return(segs)
  }
}

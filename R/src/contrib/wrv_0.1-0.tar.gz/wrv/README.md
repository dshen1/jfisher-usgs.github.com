*PROVISIONAL: FOR INFORMATION PURPOSES ONLY*

wrv
===

This [R](http://www.r-project.org/ "R") package is a pre- and post-processing
program for the [MODFLOW-USG](http://water.usgs.gov/ogw/mfusg/ "MODFLOW-USG")
numerical groundwater-flow
[model](http://www.idwr.idaho.gov/WaterInformation/Projects/woodriver/ "WRV Groundwater Flow Model")
of the Wood River Valley aquifer system, south-central Idaho.
The set of standards used for coding **wrv** is documented in
[Google's R Style Guide](http://google-styleguide.googlecode.com/svn/trunk/Rguide.xml "Google's R Style Guide").

Install
-------

If R is not already installed on your computer, download and install the latest
binary distribution from
[CRAN](http://cran.r-project.org/ "The Comprehensive R Archive Network").

Open an R session and install the following packages from CRAN:

    > install.packages(c("sp", "rgdal", "raster", "igraph", "rgeos", "RCurl", "png"))

Install the **wrv** package:

    > install.packages("wrv", repos = "<<not yet available>>")

System requirements include the latest version of MODFLOW-USG. Windows users can
[download](http://water.usgs.gov/ogw/mfusg/#downloads "MODFLOW-USG downloads")
and decompress the file archive in the default search path `C:/WRDAPP`.

Run
---

Load **wrv** in the current R session:

    > library(wrv)

Access the package documentation:

    > help(package = "wrv")

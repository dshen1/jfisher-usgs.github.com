
## ----setup, include=FALSE, cache=FALSE-----------------------------------
library(wrv)
knitr::opts_chunk$set(dev="pdf", tidy=FALSE)


## ----fig.land.surface, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Land surface topography and extent of aquifer system."----
f <- system.file("extdata/hillshade.png", package="wrv")
i <- png::readPNG(f, native=TRUE, info=TRUE)
crs <- CRS(attr(i, "info")$text)
pos <- attr(i, "metadata")
img <- list(image=i, xleft=pos[1], ybottom=pos[2], xright=pos[3], ytop=pos[4])
xlim <- c(2451504, 2497815)
ylim <- c(1342484, 1402354)
PlotMap(crs, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE,
        rivers=list(x=major.streams), lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFFCC", add=TRUE)
plot(cities, pch=15, cex=0.8, col="#333333", add=TRUE)
text(cities, labels=cities@data$CITY_NAME, col="#333333", cex=0.5, pos=1,
     offset=0.4)
lab <- cbind(map.labels@coords, map.labels@data)
for (i in 1:nrow(lab)) {
  text(lab$x[i], lab$y[i], labels=lab$label[i], cex=lab$cex[i], col=lab$col[i],
       font=lab$font[i], srt=lab$srt[i])
}


## ------------------------------------------------------------------------
fact <- 5L  # aggregation factor, the L suffix indicates that the number is an integer
r <- aggregate(raster(alluvium.bottom), fact)
names(r) <- "alluvium.bottom"
rs <- r  # initialize a raster stack, a collection of raster layers
r <- aggregate(raster(land.surface), fact)
names(r) <- "land.surface"
rs <- stack(rs, r)  # add raster layer to raster stack


## ------------------------------------------------------------------------
r <- rs[["land.surface"]] - rs[["alluvium.bottom"]]
min.thickness <- 1.0  # min. thickness for cells
is.too.thin <- r[] < min.thickness
rs[["alluvium.bottom"]][is.too.thin] <- NA
r[is.too.thin] <- NA
names(r) <- "alluvium.thickness"
rs <- stack(rs, r)


## ----fig.alluvium.thickness, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Thickness of Quaternary sediment."----
pal <- colorRampPalette(c("#F02311", "#F7FDFA", "#107FC9"))
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE, pal=pal,
        explanation="Thickness of alluvium aquifer in meters.",
        rivers=list(x=major.streams), lakes=list(x=lakes))


## ------------------------------------------------------------------------
r <- rasterize(basalt.extent, rs, getCover = TRUE, silent = TRUE)
min.coverage <- 1L  # min. percentage of each cell that is covered by the polygon (1-100)
r[r < min.coverage] <- NA
r[!is.na(r)] <- 1L  # basalt cells
r <- as.factor(r)
rat <- levels(r)[[1]]  # raster attribute table
rat$att <- "Basalt"
levels(r) <- rat
names(r) <- "basalt.extent"
rs <- stack(rs, r)


## ----fig.basalt.extent, echo=FALSE, fig.width=7.50, fig.height=5.83, fig.cap="Extent of basalt in the aquifer system."----
s.xlim <- c(2472304, 2497015)
s.ylim <- c(1343284, 1360000)
PlotMap(r, xlim=s.xlim, ylim=s.ylim, bg.image=img, dms.tick=TRUE, col="#BEAED4",
        rivers=list(x=major.streams), lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ------------------------------------------------------------------------
depth.to.basalt.bottom <- 52  # in meters
r <- rs[["land.surface"]] - depth.to.basalt.bottom
r[r > rs[["alluvium.bottom"]] | is.na(rs[["basalt.extent"]])] <- NA
basalt.bottom <- r
r <- rs[["alluvium.bottom"]]
is.basalt.cell <- !is.na(basalt.bottom)
r[is.basalt.cell] <- basalt.bottom[is.basalt.cell]
names(r) <- "bedrock"
rs <- stack(rs, r)


## ------------------------------------------------------------------------
r <- rs[["land.surface"]] - rs[["bedrock"]]
r[is.na(rs[["alluvium.bottom"]])] <- NA
names(r) <- "aquifer.thickness"
rs <- stack(rs, r)


## ----fig.aquifer.thickness, echo=FALSE, fig.width=7.50, fig.height=5.83, fig.cap="Thickness of aquifer system."----
PlotMap(r, xlim=s.xlim, ylim=s.ylim, bg.image=img, dms.tick=TRUE, pal=pal,
        explanation="Thickness of the aquifer system in meters.",
        rivers=list(x=major.streams), lakes=list(x=lakes))


## ------------------------------------------------------------------------
r <- rasterize(aquitard.extent, rs, getCover = TRUE, silent = TRUE)
r[r < min.coverage] <- NA
r[!is.na(r)] <- 1L  # clay cells
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- "Clay"
levels(r) <- rat
names(r) <- "aquitard.extent"
rs <- stack(rs, r)


## ----fig.aquitard.extent, echo=FALSE, fig.width=7.50, fig.height=5.83, fig.cap="Extent of aquitard in aquifer system."----
PlotMap(r, xlim=s.xlim, ylim=s.ylim, bg.image=img, dms.tick=TRUE, col="#FDC086",
        rivers=list(x=major.streams), lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ------------------------------------------------------------------------
aquitard.thickness <- 5  # in meters
depth.to.aquitard.top <- 30  # in meters
r <- rs[["land.surface"]] - depth.to.aquitard.top
r[r < rs[["alluvium.bottom"]] | is.na(rs[["aquitard.extent"]])] <- NA
names(r) <- "aquitard.top"
rs <- stack(rs, r)


## ----eval=F--------------------------------------------------------------
## min.overlap <- 2.0  # min. vertical overlap between adjacent cells, in meters
## r <- FindConnectedCells(rs[["bedrock"]], rs[["land.surface"]], min.overlap)
## r <- as.factor(r)
## rat <- levels(r)[[1]]
## rat$att <- c("Inactive", "Active")
## levels(r) <- rat
## names(r) <- "is.connected"
## rs <- stack(rs, r)


## ----fig.is.connected, eval=F, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Vertical connectivity among cells."----
## PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE,
##         col=c("#FF404B", "#A6CEE3"), rivers=list(x=major.streams),
##         lakes=list(x=lakes))


## ------------------------------------------------------------------------
l <- gIntersection(as(source.locations, "SpatialLinesDataFrame"), aquifer.extent, TRUE)
source.lines <- SpatialLinesDataFrame(l, data = source.locations@data, match.ID = FALSE)
r <- rs[["alluvium.bottom"]]
is.in.aquifer <- !is.na(r)
is.in.poly <- !is.na(rasterize(source.locations, rs, silent = TRUE))
is.on.line <- !is.na(rasterize(source.lines, rs))
r[is.in.aquifer &  is.in.poly] <- 0L  # inactive cells
r[is.in.aquifer & !is.in.poly] <- 1L  # active cells
r[is.in.aquifer &  is.on.line] <- 2L  # source cells
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- c("Inactive", "Active", "Source")
levels(r) <- rat
names(r) <- "is.below.src"
rs <- stack(rs, r)


## ----fig.is.below.src, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Source cells in aquifer system."----
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE,
        col=c("#FF404B", "#A6CEE3", "#000000"), rivers=list(x=major.streams),
        lakes=list(x=lakes))


## ------------------------------------------------------------------------
r <- rs[["land.surface"]] - depth.to.aquitard.top
r[is.na(rs[["alluvium.bottom"]])] <- NA
is.below <- rs[["alluvium.bottom"]] > r
r[is.below] <- rs[["alluvium.bottom"]][is.below]
r[(rs[["land.surface"]] - r) < min.thickness] <- NA  # enforce min. thickness for layers
if ("is.connected" %in% names(rs))
  r[rs[["is.connected"]] == 0L] <- NA
r[rs[["is.below.src"]] == 0L] <- NA
r <- ExcludeSmallCellChunks(r)  # ensure horizontal connectivity among cells
names(r) <- "lay1.bottom"
rs.model <- r  # initialize second raster stack for model input


## ------------------------------------------------------------------------
r <- rs.model[["lay1.bottom"]] - aquitard.thickness
is.below <- rs[["bedrock"]] > r
r[is.below] <- rs[["bedrock"]][is.below]
r[(rs.model[["lay1.bottom"]] - r) < min.thickness] <- NA  # enforce min. thickness
r <- ExcludeSmallCellChunks(r)
names(r) <- "lay2.bottom"
rs.model <- stack(rs.model, r)


## ------------------------------------------------------------------------
r <- rs[["bedrock"]]
r[is.na(rs.model[["lay2.bottom"]])] <- NA
r[(rs.model[["lay2.bottom"]] - r) < min.thickness] <- NA  # enforce min. thickness
r <- ExcludeSmallCellChunks(r)
names(r) <- "lay3.bottom"
rs.model <- stack(rs.model, r)


## ------------------------------------------------------------------------
r <- rs.model[["lay1.bottom"]]
is.adjusted <- r > rs[["bedrock"]] & is.na(rs.model[["lay2.bottom"]])
r[is.adjusted] <- rs[["bedrock"]][is.adjusted]
r <- ExcludeSmallCellChunks(r)
rs.model[["lay1.bottom"]] <- r


## ------------------------------------------------------------------------
r <- rs[["land.surface"]]
r[is.na(rs.model[["lay1.bottom"]])] <- NA
names(r) <- "lay1.top"
rs.model <- stack(rs.model, r)


## ----echo=FALSE----------------------------------------------------------
r <- rs[["land.surface"]] - rs.model[["lay1.bottom"]]
names(r) <- "lay1.thickness"
rs.model <- stack(rs.model, r)

r <- rs.model[["lay1.bottom"]] - rs.model[["lay2.bottom"]]
names(r) <- "lay2.thickness"
rs.model <- stack(rs.model, r)

r <- rs.model[["lay2.bottom"]] - rs.model[["lay3.bottom"]]
names(r) <- "lay3.thickness"
rs.model <- stack(rs.model, r)


## ------------------------------------------------------------------------
r <- rs.model[["lay1.bottom"]]
r[!is.na(r)] <- 1L  # alluvium cells
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- "Alluvium"
levels(r) <- rat
names(r) <- "lay1.zones"
rs.model <- stack(rs.model, r)


## ----fig.lay1.zones, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Hydrogeologic zones in model layer 1."----
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE, col="#7FC97F",
        rivers=list(x=major.streams), lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ------------------------------------------------------------------------
r <- rs.model[["lay2.bottom"]]
r[!is.na(r)] <- 1L  # alluvium cells
r[!is.na(r) & !is.na(rs[["aquitard.extent"]])] <- 3L  # clay cells
r[rs.model[["lay2.bottom"]] < rs[["alluvium.bottom"]]] <- 2L  # basalt cells
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- c("Alluvium", "Basalt", "Clay")
levels(r) <- rat
names(r) <- "lay2.zones"
rs.model <- stack(rs.model, r)


## ----fig.lay2.zones, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Hydrogeologic zones in model layer 2."----
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE,
        col=c("#7FC97F", "#BEAED4", "#FDC086"), rivers=list(x=major.streams),
        lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ------------------------------------------------------------------------
r <- rs.model[["lay3.bottom"]]
r[!is.na(r)] <- 1L  # alluvium cells
r[rs.model[["lay3.bottom"]] < rs[["alluvium.bottom"]]] <- 2L  # basalt cells
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- c("Alluvium", "Basalt")
levels(r) <- rat
names(r) <- "lay3.zones"
rs.model <- stack(rs.model, r)


## ----fig.lay3.zones, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Hydrogeologic zones in model layer 3."----
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE,
        col=c("#7FC97F", "#BEAED4"), rivers=list(x=major.streams),
        lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ----tbl.vol.flux, echo=FALSE, results="asis"----------------------------
d <- source.lines@data[, c("Name", "Flow")]
d[, 3] <- d[, 2] * 0.296106669
colnames(d) <- c("Name", "Flow (m3/d)", "Flow (acre-ft/yr)")
tbl <- xtable::xtable(d, label="tbl.vol.flux",
                      caption="Volumetric flux in tributaries.")
xtable::digits(tbl)[3:4] <- c(0, 0)
print(tbl, include.rownames=FALSE)


## ------------------------------------------------------------------------
r <- rs.model[[1]]
r[] <- NA
r.src <- rasterize(source.lines, r)
is.active <- !is.na(rs.model[["lay1.bottom"]][])
r.src[!is.active] <- NA

src.cells <- which(!is.na(r.src[]))
adj.cells <- adjacent(r.src, src.cells, directions = 4)
is.valid.src <- adj.cells[, 2] %in% which(is.active)
rm.src.cells <- src.cells[!(src.cells %in% unique(adj.cells[is.valid.src, 1]))]
rs.model[["lay1.bottom"]][rm.src.cells] <- NA
rs.model[["lay1.top"]][rm.src.cells] <- NA
r.src[rm.src.cells] <- NA

rat <- levels(r.src)[[1]]
for (i in 1:nrow(rat)) {
  trib.cells <- which(r.src[] == rat$ID[i])
  r[trib.cells] <- rat$Flow[i] / length(trib.cells)
}
names(r) <- "lay1.bdry.sources"
rs.model <- stack(rs.model, r)


## ------------------------------------------------------------------------
l <- gIntersection(sink.locations, as(aquifer.extent, "SpatialLinesDataFrame"), TRUE)
sink.lines <- SpatialLinesDataFrame(l, data = sink.locations@data, match.ID = FALSE)
r <- rasterize(sink.lines, rs.model, field = "Head")
r[!is.na(r) & is.na(rs.model[["lay1.bottom"]])] <- NA
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- c("Silver Creek", "Staton Crossing")
levels(r) <- rat
names(r) <- "lay1.bdry.sinks"
rs.model <- stack(rs.model, r)
r <- rasterize(sink.lines, rs.model, field = "Head")
r[!is.na(r) & is.na(rs.model[["lay2.bottom"]])] <- NA
names(r) <- "lay2.bdry.sinks"
rs.model <- stack(rs.model, r)
r <- rasterize(sink.lines, rs.model, field = "Head")
r[!is.na(r) & is.na(rs.model[["lay3.bottom"]])] <- NA
names(r) <- "lay3.bdry.sinks"
rs.model <- stack(rs.model, r)


## ----tbl.drain.head, echo=FALSE, results="asis"--------------------------
d <- sink.lines@data[, c("Name", "Head")]
d[, 3] <- d[, 2] * 3.28084
colnames(d) <- c("Name", "Head (m)", "Head (ft)")
tbl <- xtable::xtable(d, label="tbl.drain.head",
                      caption="Specified hydraulic head thresholds for sink boundary conditions.")
xtable::digits(tbl)[3:4] <- c(0, 0)
print(tbl, include.rownames=FALSE)


## ----fig.lay1.sinks, echo=FALSE, fig.width=7.50, fig.height=5.83, fig.cap="Sink cells in model layer 1."----
r <- rs.model[["lay1.bdry.sinks"]]
PlotMap(r, xlim=s.xlim, ylim=s.ylim, bg.image=img, dms.tick=TRUE,
        col=c("#900E49", "#F2AB05"), rivers=list(x=major.streams),
        lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ------------------------------------------------------------------------
rs.model <- crop(rs.model, trim(rs.model[["lay1.bottom"]]))


## ----tbl.model.str, echo=FALSE, results="asis"---------------------------
att <- c("Number of rows", "Number of columns", "Number of layers",
         "Uniform x spacing (m)", "Uniform y spacing (m)",
         "World coordinates of model origin x (m)",
         "World coordinates of model origin y (m)")
val <- c(nrow(rs.model), ncol(rs.model), 3, res(rs.model), xmin(rs.model),
         ymin(rs.model))
d <- as.data.frame(list(Attribute=att, Value=val))
tbl <- xtable::xtable(d, label="tbl.model.str",
                      caption="Summary of the model grid attributes.")
xtable::digits(tbl)[3] <- 0
print(tbl, include.rownames=FALSE)


## ------------------------------------------------------------------------
r <- rs.model[["lay1.bottom"]]
r[] <- as.integer(!is.na(r[]))
names(r) <- "lay1.ibound"
rs.model <- stack(rs.model, r)
r <- rs.model[["lay2.bottom"]]
r[] <-  as.integer(!is.na(r[]))
names(r) <- "lay2.ibound"
rs.model <- stack(rs.model, r)
r <- rs.model[["lay3.bottom"]]
r[] <-  as.integer(!is.na(r[]))
names(r) <- "lay3.ibound"
rs.model <- stack(rs.model, r)


## ------------------------------------------------------------------------
initial.head.frac <- 0.90  # fraction
r <- rs.model[["lay1.bottom"]] + rs.model[["lay1.thickness"]] * initial.head.frac
names(r) <- "lay1.strt"
rs.model <- stack(rs.model, r)
r <- rs.model[["lay1.strt"]]
r[is.na(rs.model[["lay2.bottom"]])] <- NA
names(r) <- "lay2.strt"
rs.model <- stack(rs.model, r)
r <- rs.model[["lay1.strt"]]
r[is.na(rs.model[["lay3.bottom"]])] <- NA
names(r) <- "lay3.strt"
rs.model <- stack(rs.model, r)


## ----eval=TRUE-----------------------------------------------------------
p <- file.path(getwd(), format(Sys.time(), "%Y%m%d%H%M%S"))
dir.create(path = p)
ExportRasterStack(file.path(p, "Data"), rs)
ExportRasterStack(file.path(p, "Model"), rs.model)


## ----eval=TRUE-----------------------------------------------------------
id <- "wrv_ss_mfusg"  # identifier for model run
perlen <- 5479  # in days, period length
hk <- c(30.48, 86.40, 8.64e-7)  # in m/d, horiz. conductivity of alluvium, basalt, clay
vani <- 1000  # vertical anisotropy
p.run <- file.path(p, "Run")
CreateModflowInputFiles(rs.model, id, p.run, perlen, hk, vani)


## ------------------------------------------------------------------------
if (.Platform$OS.type == "windows") {
  f <- file.path(p.run, "Run.bat")
  p.exe <- "C:/WRDAPP/mfusg.1_1/bin/mfusg_x64.exe"  # path to MODFLOW-USG executable
  cmd <- paste(Sys.getenv("COMSPEC"), "/c", paste0(p.exe, " ", id, ".nam"))
  cat(c(paste("CD", "/d", p.run), cmd), file = f, sep = "\n")
  output <- system(shQuote(f), intern = TRUE)
}


## ----echo=FALSE----------------------------------------------------------
cat(paste(output[6:length(output)], collapse = "\n"), "\n")


## ------------------------------------------------------------------------
f <- file.path(p.run, paste0(id, ".hds"))
r <- rs.model[[1]]
rs.heads <- ReadModflowBinaryFile(f, r)


## ------------------------------------------------------------------------
r <- rs.heads[[1]] > rs.model[["lay1.top"]] & rs.heads[[1]] < 1e30
names(r) <- "lay1.saturated"
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- c("Partially Saturated", "Saturated")
levels(r) <- rat
rs.heads <- stack(rs.heads, r)


## ----fig.lay1.sat, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Saturated cells in model layer 1."----
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE,
        col=c("#91CC9B", "#FF6E61"), rivers=list(x=major.streams),
        lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ----fig.water.table, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Simulated elevation of the water table."----
r <- rs.heads[["ts1.sp1.lay1"]]
pal <- colorRampPalette(c("#ABEEF2", "#E2DAAA", "#BAF788"))
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE, pal=pal,
        explanation="Elevation of simulated water table in meters above NAVD 88.",
        rivers=list(x=major.streams), lakes=list(x=lakes))



## ------------------------------------------------------------------------
ExportRasterStack(p.run, rs.heads)


## ----echo=FALSE, results="asis"------------------------------------------
print(toLatex(sessionInfo(), locale=FALSE))



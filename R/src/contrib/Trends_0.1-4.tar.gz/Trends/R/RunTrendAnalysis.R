RunTrendAnalysis <- function(d, site.names, par.config, plot.config, sdate=NA,
                             edate=NA, is.censored=FALSE, path.out=tempfile(""),
                             gr.type="pdf", cenken.tol=1e-12, cenken.iter=1e+6,
                             dt.breaks=NULL, xout=FALSE, draw.ci=FALSE,
                             site.locs=NULL, merge.pdfs=FALSE) {

  # Additional functions:

  # Trim leading and trailing white space from character string
  Trim <- function(s) {
    return(sub("^[[:space:]]*(.*?)[[:space:]]*$", "\\1", s, perl=TRUE))
  }

  # Calculate percentage change in slope and uncertainties
  # Temporal units must be consistant with slope
  PercentChange <- function(slope, intercept, tlim) {
    t1 <- as.numeric(tlim[1])
    t2 <- as.numeric(tlim[2])
    c1 <- slope * t1 + intercept
    c2 <- slope * t2 + intercept
    return((((c2 / c1) - 1) / (t2 - t1)) * 100)
  }

  # Classify trend using p-value and slope
  ClassifyTrend <- function(p, slope, tol=0.05) {
    if (!is.numeric(p) || !is.numeric(slope))
      return("no trend")
    is.sig.trend <- p <= tol
    is.pos.slope <- slope > 0
    if (is.sig.trend) {
      if (is.pos.slope)
        return("+")
      else
        return("-")
    } else {
      return("no trend")
    }
  }

  # Open and close graphics device
  GrDev <- function(site, plot.count) {
    if (gr.type != "windows")
      graphics.off()
    site <- paste0(site, "_", LETTERS[((4L + plot.count) - 1L) %/% 4L])
    OpenDevice(path.out, site, gr.type)
  }


  # Main program:

  options(stringsAsFactors=FALSE)

  # Create output directory
  dir.create(path=path.out, showWarnings=FALSE, recursive=TRUE)

  # Determine background color for legend box
  leg.box.col <- ifelse(gr.type == "postscript", "#FFFFFF", "#FFFFFFBB")

  # Column names in data table
  d.names <- names(d)

  # Read data from statistics tables and combine
  is.valid.site.id <- plot.config$Site_id %in% d$Site_id
  if (!all(is.valid.site.id)) {
    ids <- plot.config[!is.valid.site.id, c("Site_id", "Site_name"), drop=FALSE]
    msg <- paste(paste0("id: ", ids$Site_id, ", name: ", ids$Site_name),
                 collapse="\n")
    warning("Ids in stats configuration file do not match data:\n", msg, "\n")
  }
  plot.config <- plot.config[is.valid.site.id, ]

  # Convert date arguments into POSIXct class
  sdate <- as.POSIXct(sdate, "%m/%d/%Y", tz="")
  edate <- as.POSIXct(edate, "%m/%d/%Y", tz="")

  # Output table
  obj.out <- NULL

  # Identify row index numbers of table
  if (missing(site.names))
    idxs <- seq_len(nrow(plot.config))
  else
    idxs <- which(plot.config$Site_name %in% site.names)

  # Number of seconds in year, used for time conversions
  secs.in.year <- 31536000

  # Initialize plot count list
  plot.count <- list()

  # Loop though records in statistic table

  for (i in seq_along(idxs)) {
    idx <- idxs[i]

    id    <- plot.config[idx, "Site_id"]
    site  <- plot.config[idx, "Site_name"]

    p.names <- Trim(unique(unlist(strsplit(plot.config[idx, "Parameters"], ","))))
    parameters <- make.names(p.names)

    # Initialize plot count
    if (is.null(plot.count[[site]]))
      plot.count[[site]] <- 0L

    # Loop through parameters in record

    for (j in seq_along(parameters)) {
      parameter <- parameters[j]
      if (!parameter %in% d.names) {
        txt <- paste0("Parameter is not recognized and will be skipped:\n",
                      "Row index: ", idx, ", Column name: Parameters, ",
                      "String: ", parameter, "\n")
        warning(txt)
        next
      }

      # Start record that will be added to output table
      lst <- list("Site_id"=id, "Site_name"=site, "Parameter"=p.names[j],
                  "Start_date"=sdate, "End_date"=edate)
      rec <- as.data.frame(lst, optional=TRUE)

      # Determine pertinent column names in data table
      col.names <- c("Datetime", parameter)
      col.code.name <- paste0(parameter, "_code")
      is.code <- col.code.name %in% d.names
      if (is.code)
        col.names <- c(col.names, col.code.name)
      else
        col.code.name <- NULL

      # Reduce size of data table
      is.id <- d$Site_id == id
      is.gt.sd <- if (is.na(sdate)) TRUE else d$Datetime >= sdate
      is.lt.ed <- if (is.na(edate)) TRUE else d$Datetime <= edate
      d.id <- d[is.id & is.gt.sd & is.lt.ed, col.names]

      # Order by date-time variable
      d.id <- d.id[order(d.id$Datetime), ]

      # Determine the number of samples that are below the recording limit
      n.lt.rl <- if (is.code) sum(d.id[[col.code.name]] == 1) else 0L

      # Text to append to error messages
      err.extra <- paste0("Row index: ", idx, ", Site name: ", site,
                          ", Parameter: ", parameter, "\n")

      # y-axis label
      ylab <- par.config[parameter, "Name"]
      if (!is.na(par.config[parameter, "Units"]))
        ylab <- paste(ylab, par.config[parameter, "Units"], sep=", in ")

      # Start statistical analysis

      # Censored data:
      if (is.censored) {

        # Remove any row with NA values
        d.id <- na.omit(d.id)
        n <- nrow(d.id)

        # Identify censored data
        if (is.code)
          is.cen <- d.id[[col.code.name]] %in% 1L
        else
          is.cen <- rep(FALSE, nrow(d.id))

        # Warn if no censored data found
        if (!any(is.cen)) {
          txt <- "No censored data found in censored statistical analysis:"
          warning(paste(txt, err.extra, sep="\n"))
        }

        regr <- NULL
        lst <- list(n=NA, n_above_rl=NA, n_cen=NA, mean=NA, median=NA, min=NA,
                    max=NA, std_dev=NA, len_record=NA, p_value=NA, tau=NA,
                    slope=NA, int=NA, slope_percent=NA)

        # Basic summary statistics
        dat <- d.id[[parameter]]
        ans <- try(suppressWarnings(cenfit(dat, is.cen)), silent=TRUE)
        if (inherits(ans, "try-error")) {
          warning(paste("NADA cenfit error:", err.extra, sep="\n"))
          next
        }

        lst$n          <- ans@survfit$n
        lst$n_above_rl <- ans@survfit$n - n.lt.rl
        lst$n_cen      <- ans@survfit$n - sum(ans@survfit$n.event)
        lst$min        <- min(dat)
        lst$max        <- max(dat)
        lst$len_record <- diff(range(d.id$Datetime))

        # Compute trend if complete cenfit results
        if (!is.na(median(ans))) {

          lst$mean    <- mean(ans)["mean"]
          lst$std_dev <- sd(ans)
          lst$median  <- median(ans)

          # Kendall's tau correlation coefficient and Akritas-Theil-Sen
          # nonparametric regression line, see ?cenken
          x <- as.numeric(d.id$Datetime)
          ans <- try(NADA:::kendallATS(y=dat, ycen=is.cen, x=x,
                                       xcen=rep(FALSE, length(x)),
                                       tol=cenken.tol, iter=cenken.iter),
                                       silent=TRUE)
###       ans <- cenken(y=dat, ycen=is.cen, x=x, xcen=rep(FALSE, length(x)))
          if (inherits(ans, "try-error")) {
            warning(paste("NADA kendallATS error:", err.extra, sep="\n"))
            next
          }

          # Calculate percentage change per year in slopes
          slope.percent <- PercentChange(ans$slope, ans$intercept,
                                         tlim=range(d.id$Datetime))

          # Nonparametric line
          if (is.numeric(ans$slope) && is.numeric(ans$intercept))
            regr <- function(x) {ans$slope * as.numeric(x) + ans$intercept}

          # Place summary statistics in list
          lst$p_value       <- ans$p
          lst$tau           <- ans$tau
          lst$slope         <- ans$slope * secs.in.year
          lst$int           <- ans$intercept
          lst$slope_percent <- slope.percent * secs.in.year
        }

        # Add summary record to output table
        rec <- cbind(rec, as.data.frame(lst, optional=TRUE))

        # Convert censored data code to logical
        if (is.code)
          d.id[[col.code.name]] <- d.id[[col.code.name]] == 1L

        # Draw plot
        plot.count[[site]] <- plot.count[[site]] + 1L
        if (((4L + plot.count[[site]]) - 1L) %% 4L == 0L) {
          GrDev(site, plot.count[[site]])
          main <- paste0(site, " (", id, ")")
        } else {
          main <- NULL
        }
        DrawPlot(d.id, par.config[parameter, ], cen.var=col.code.name,
                 xlim=c(sdate, edate), regr=regr,
                 regr.type="Akritas-Theil-Sen line",
                 main=main, ylab=ylab, leg.box.col=leg.box.col, p.value=ans$p)

        # Classify trend
        ans <- ClassifyTrend(rec[1, "p_value"], rec[1, "slope"])
        lst <- list(trend=ans)
        rec <- cbind(rec, as.data.frame(lst, optional=TRUE))

      # Uncensored data:
      } else {

        # Warn if censored data found
        if (is.code) {
          n.cen <- as.integer(sum(d.id[[col.code.name]] %in% 1))
          if (n.cen > 0) {
            txt <- "Censored data found in uncensored analysis, not plotted:"
            warning(paste(txt, err.extra, sep="\n"))
            next
          }
        } else {
          n.cen <- 0L
        }

        # Basic summary statistics
        dat <- na.omit(d.id[[parameter]])
        n <- length(dat)
        lst <- list("n"=n, "n_above_rl"=n - n.lt.rl, "n_cen"=n.cen,
                    "mean"=mean(dat), "median"=median(dat),
                    "min"=min(dat), "max"=max(dat), "std_dev"=sd(dat))
        rec <- cbind(rec, as.data.frame(lst, optional=TRUE))

        # Length of temporal record
        tlim <- range(d.id$Datetime)
        lst <- list("len_record"=diff(tlim))
        rec <- cbind(rec, as.data.frame(lst))

        # Average values over date-time intervals
        if (!is.null(dt.breaks)) {

          # Determine date cuts based on time interval
          ans <- try(cut(d.id$Datetime, dt.breaks), silent=TRUE)
          if (inherits(ans, "try-error")) {
            warning(paste("Time cut error:", ans, err.extra, sep="\n"))
            next
          } else {
            d.id.cuts <- as.POSIXct(ans, "%Y-%m-%d", tz="")
          }

          # Time average constituent based on date cuts
          ans <- try(aggregate(d.id, list(date=d.id.cuts),
                               function(i) mean(i, na.rm=TRUE)), silent=TRUE)
          if (inherits(ans, "try-error")) {
            warning(paste("Time average error:", ans, err.extra, sep="\n"))
            next
          } else {
            d.id <- na.omit(ans[, c("date", parameter)])
            names(d.id) <- c("Datetime", parameter)
          }
        }

        # Calculate Theil-Sen estimator and trend line using R.R. Wilcox'
        # functions
        x <- as.numeric(d.id$Datetime)
        y <- d.id[, parameter]

        est <- try(RunTheilSen(x=x, y=y, xout=xout)$regci, silent=TRUE)
        if (inherits(est, "try-error") | is.null(est)) {
          warning(paste("Wilcox regci error:", err.extra, sep="\n"))
          next
        }
        est <- list("p_value"  =est[2, 5],
                    "slope"    =est[2, 3],
                    "lower"    =est[2, 1],
                    "upper"    =est[2, 2],
                    "int"      =est[1, 3],
                    "int_lower"=est[1, 1],
                    "int_upper"=est[1, 2])

        # Regression line and confidence intervals
        regr <- regr.lower <- regr.upper <- NULL
        if (is.numeric(est$slope) && is.numeric(est$int)) {
          regr <- function(x) {est$slope * as.numeric(x) + est$int}
          if (draw.ci) {
            regr.lower <- function(x) {est$lower * as.numeric(x) + est$int_lower}
            regr.upper <- function(x) {est$upper * as.numeric(x) + est$int_upper}
          }
        }

        # Draw plot
        plot.count[[site]] <- plot.count[[site]] + 1L
        if (((4L + plot.count[[site]]) - 1L) %% 4L == 0L) {
          GrDev(site, plot.count[[site]])
          main <- paste0(site, " (", id, ")")
        } else {
          main <- NULL
        }
        DrawPlot(d.id[, c("Datetime", parameter)],
                 par.config[parameter, ], xlim=c(sdate, edate),
                 regr=regr, regr.lower=regr.lower, regr.upper=regr.upper,
                 regr.type="Theil-Sen line", main=main, ylab=ylab,
                 leg.box.col=leg.box.col, p.value=est$p)

        # Calculate percentage change per year in slopes
        est$slope_percent <- PercentChange(est$slope, est$int, tlim)
        est$lower_percent <- PercentChange(est$lower, est$int_lower, tlim)
        est$upper_percent <- PercentChange(est$upper, est$int_upper, tlim)

        # Convert slopes from units per second to units per year
        est$slope <- est$slope * secs.in.year
        est$lower <- est$lower * secs.in.year
        est$upper <- est$upper * secs.in.year
        est$slope_percent <- est$slope_percent * secs.in.year
        est$lower_percent <- est$lower_percent * secs.in.year
        est$upper_percent <- est$upper_percent * secs.in.year
        rec <- cbind(rec, as.data.frame(est))

        # Classify trend
        trend <- ClassifyTrend(rec[1, "p_value"], rec[1, "slope"])
        lst <- list("trend"=trend)
        rec <- cbind(rec, as.data.frame(lst, optional=TRUE))
      }

      # Add statistics record to table
      obj.out <- rbind(obj.out, rec)
    }
  }

  if (gr.type != "windows")
    graphics.off()

  rownames(obj.out) <- seq_len(nrow(obj.out))

  f <- file.path(dirname(path.out), paste0(basename(path.out), ".tsv"))
  write.table(format(obj.out, scientific=FALSE), file=f, quote=FALSE,
              sep="\t", row.names=FALSE)

  if (inherits(site.locs, "SpatialPointsDataFrame")) {
    idxs <- match(obj.out$Site_id, site.locs@data$Site_id)
    if (any(is.na(idxs))) {
      warning("Site ids in 'site.locs' do not match those in 'd'")
    } else {
      coords <- site.locs@coords[idxs, ]
      crs <- site.locs@proj4string
      obj.out$len_record <- format(obj.out$len_record)
      obj.out <- SpatialPointsDataFrame(coords, data=obj.out, proj4string=crs,
                                        match.ID=FALSE)
      writeOGR(obj.out, dirname(path.out), basename(path.out),
               driver="ESRI Shapefile")
    }
  }

  if (gr.type == "pdf" && merge.pdfs)
    MergePDFs(path.out)

  invisible(obj.out)
}

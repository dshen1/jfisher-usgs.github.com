ReadModflowBinaryFile <- function(f, r) {
  con <- file(f, open="rb", encoding="bytes")
  rs <- NULL

  while (TRUE) {
    kstp <- readBin(con, "integer", n=1L, size=4L)  # time step number
    if (length(kstp) == 0)
      break

    kper   <- readBin(con, "integer", n=1L, size=4L)  # stress period number
    pertim <- readBin(con, "numeric", n=1L, size=4L)  # time in current stress period
    totim  <- readBin(con, "numeric", n=1L, size=4L)  # total elapsed time
    desc   <- readBin(readBin(con, "raw", n=16L, size=1L), "character", n=1L)  # variable name
    ncol   <- readBin(con, "integer", n=1L, size=4L)  # number of columns
    nrow   <- readBin(con, "integer", n=1L, size=4L)  # number of rows
    ilay   <- readBin(con, "integer", n=1L, size=4L)  # layer number
    v      <- readBin(con, "numeric", n=nrow * ncol, size=4L)

    d <- matrix(v, nrow=nrow, ncol=ncol, byrow=TRUE)
    d[d == 0] <- NA
    values(r) <- d
    names(r) <- paste0("ts", kstp, ".sp", kper, ".lay", ilay)
    if (is.null(rs))
      rs <- r
    else
      rs <- stack(rs, r)
  }

  close(con)
  return(rs)
}


## ----setup, include=FALSE, cache=FALSE-----------------------------------
knitr::opts_chunk$set(dev="pdf", tidy=FALSE)
ptime <- proc.time()
library(xtable)
library(png)
library(wrv)


## ----eval=FALSE----------------------------------------------------------
## install.packages(c("rgdal", "raster", "igraph", "rgeos", "RCurl", "png", "xtable"))
## install.packages("wrv", repos = "http://jfisher-usgs.github.com/R/")


## ----eval=FALSE----------------------------------------------------------
## library(wrv)
## help(package = "wrv")


## ------------------------------------------------------------------------
p.exe <- "C:/WRDAPP/mfusg.1_1/bin/mfusg_x64.exe"  # path specified with forward slashes


## ----fig_land_surface, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Land surface topography and extent of the aquifer system."----
f <- system.file("extdata", "hillshade.png", package="wrv")
i <- readPNG(f, native=TRUE, info=TRUE)
crs <- CRS(attr(i, "info")$text)
pos <- attr(i, "metadata")
img <- list(image=i, xleft=pos[1], ybottom=pos[2], xright=pos[3], ytop=pos[4])
xlim <- c(2451504, 2497815)
ylim <- c(1342484, 1402354)
PlotMap(crs, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE,
        rivers=list(x=rivers), lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFFCC", add=TRUE)
plot(cities, pch=15, cex=0.8, col="#333333", add=TRUE)
text(cities, labels=cities@data$CITY_NAME, col="#333333", cex=0.5, pos=1,
     offset=0.4)
lab <- cbind(map.labels@coords, map.labels@data)
for (i in seq_len(nrow(lab))) {
  text(lab$x[i], lab$y[i], labels=lab$label[i], cex=lab$cex[i], col=lab$col[i],
       font=lab$font[i], srt=lab$srt[i])
}


## ------------------------------------------------------------------------
fact <- 5L  # aggregation factor, the L suffix indicates that the number is an integer
r <- aggregate(raster(alluvium.bottom), fact)
names(r) <- "alluvium.bottom"
rs <- r  # initialize a raster stack, a collection of raster layers
r <- aggregate(raster(land.surface), fact)
names(r) <- "land.surface"
rs <- stack(rs, r)  # add raster layer to raster stack


## ------------------------------------------------------------------------
r <- rs[["land.surface"]] - rs[["alluvium.bottom"]]
min.thickness <- 1.0  # min. thickness for cells
is.too.thin <- r[] < min.thickness
rs[["alluvium.bottom"]][is.too.thin] <- NA
r[is.too.thin] <- NA
names(r) <- "alluvium.thickness"
rs <- stack(rs, r)


## ----fig_alluvium_thickness, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Thickness of Quaternary sediment in the aquifer system."----
pal <- colorRampPalette(c("#F02311", "#F7FDFA", "#107FC9"))
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE, pal=pal,
        explanation="Thickness of alluvium aquifer in meters.",
        rivers=list(x=rivers), lakes=list(x=lakes))


## ------------------------------------------------------------------------
r <- rasterize(basalt.extent, rs, getCover = TRUE, silent = TRUE)
min.coverage <- 1L  # min. percentage of each cell that is covered by the polygon (1-100)
r[r < min.coverage] <- NA
r[!is.na(r)] <- 1L  # basalt cells
r <- as.factor(r)
rat <- levels(r)[[1]]  # raster attribute table
rat$att <- "Basalt"
levels(r) <- rat
names(r) <- "basalt.extent"
rs <- stack(rs, r)


## ----fig_basalt_extent, echo=FALSE, fig.width=7.50, fig.height=5.83, fig.cap="Extent of basalt in the aquifer system."----
s.xlim <- c(2472304, 2497015)
s.ylim <- c(1343284, 1360000)
PlotMap(r, xlim=s.xlim, ylim=s.ylim, bg.image=img, dms.tick=TRUE, col="#BEAED4",
        rivers=list(x=rivers), lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ------------------------------------------------------------------------
depth.to.basalt.bottom <- 52  # in meters
r <- rs[["land.surface"]] - depth.to.basalt.bottom
r[r > rs[["alluvium.bottom"]] | is.na(rs[["basalt.extent"]])] <- NA
basalt.bottom <- r
r <- rs[["alluvium.bottom"]]
is.basalt.cell <- !is.na(basalt.bottom)
r[is.basalt.cell] <- basalt.bottom[is.basalt.cell]
names(r) <- "bedrock"
rs <- stack(rs, r)


## ------------------------------------------------------------------------
r <- rs[["land.surface"]] - rs[["bedrock"]]
r[is.na(rs[["alluvium.bottom"]])] <- NA
names(r) <- "aquifer.thickness"
rs <- stack(rs, r)


## ----fig_aquifer_thickness, echo=FALSE, fig.width=7.50, fig.height=5.83, fig.cap="Thickness of the aquifer system."----
PlotMap(r, xlim=s.xlim, ylim=s.ylim, bg.image=img, dms.tick=TRUE, pal=pal,
        explanation="Thickness of the aquifer system in meters.",
        rivers=list(x=rivers), lakes=list(x=lakes))


## ------------------------------------------------------------------------
r <- rasterize(aquitard.extent, rs, getCover = TRUE, silent = TRUE)
r[r < min.coverage] <- NA
r[!is.na(r)] <- 1L  # clay cells
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- "Clay"
levels(r) <- rat
names(r) <- "aquitard.extent"
rs <- stack(rs, r)


## ----fig_aquitard_extent, echo=FALSE, fig.width=7.50, fig.height=5.83, fig.cap="Extent of aquitard in the aquifer system."----
PlotMap(r, xlim=s.xlim, ylim=s.ylim, bg.image=img, dms.tick=TRUE, col="#FDC086",
        rivers=list(x=rivers), lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ------------------------------------------------------------------------
aquitard.thickness <- 5  # in meters
depth.to.aquitard.top <- 30  # in meters
r <- rs[["land.surface"]] - depth.to.aquitard.top
r[r < rs[["alluvium.bottom"]] | is.na(rs[["aquitard.extent"]])] <- NA
names(r) <- "aquitard.top"
rs <- stack(rs, r)


## ----eval=TRUE-----------------------------------------------------------
min.overlap <- 2  # min. vertical overlap between adjacent cells, in meters
r <- FindConnectedCells(rs[["bedrock"]], rs[["land.surface"]], min.overlap)
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- c("Inactive", "Active")
levels(r) <- rat
names(r) <- "is.connected"
rs <- stack(rs, r)


## ----fig_is_connected, eval=TRUE, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Vertical connectivity among cells."----
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE,
        col=c("#FF404B", "#A6CEE3"), rivers=list(x=rivers),
        lakes=list(x=lakes))


## ------------------------------------------------------------------------
l <- gIntersection(as(source.locations, "SpatialLinesDataFrame"), aquifer.extent, TRUE)
source.lines <- SpatialLinesDataFrame(l, data = source.locations@data, match.ID = FALSE)
r <- rs[["alluvium.bottom"]]
is.in.aquifer <- !is.na(r)
is.in.poly <- !is.na(rasterize(source.locations, rs, silent = TRUE))
is.on.line <- !is.na(rasterize(source.lines, rs))
r[is.in.aquifer &  is.in.poly] <- 0L  # inactive cells
r[is.in.aquifer & !is.in.poly] <- 1L  # active cells
r[is.in.aquifer &  is.on.line] <- 2L  # source cells
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- c("Inactive", "Active", "Source")
levels(r) <- rat
names(r) <- "is.below.src"
rs <- stack(rs, r)


## ----fig_is_below_src, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Location of source cells in the aquifer system."----
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE,
        col=c("#FF404B", "#A6CEE3", "#000000"), rivers=list(x=rivers),
        lakes=list(x=lakes))


## ------------------------------------------------------------------------
r <- rs[["land.surface"]] - depth.to.aquitard.top
r[is.na(rs[["alluvium.bottom"]])] <- NA
is.below <- rs[["alluvium.bottom"]] > r
r[is.below] <- rs[["alluvium.bottom"]][is.below]
r[(rs[["land.surface"]] - r) < min.thickness] <- NA  # enforce min. thickness for layers
if ("is.connected" %in% names(rs))
  r[rs[["is.connected"]] == 0L] <- NA
r[rs[["is.below.src"]] == 0L] <- NA
r <- ExcludeSmallCellChunks(r)  # ensure horizontal connectivity among cells
names(r) <- "lay1.bottom"
rs.model <- r  # initialize second raster stack for model input


## ------------------------------------------------------------------------
r <- rs.model[["lay1.bottom"]] - aquitard.thickness
is.below <- rs[["bedrock"]] > r
r[is.below] <- rs[["bedrock"]][is.below]
r[(rs.model[["lay1.bottom"]] - r) < min.thickness] <- NA  # enforce min. thickness
r <- ExcludeSmallCellChunks(r)
names(r) <- "lay2.bottom"
rs.model <- stack(rs.model, r)


## ------------------------------------------------------------------------
r <- rs[["bedrock"]]
r[is.na(rs.model[["lay2.bottom"]])] <- NA
r[(rs.model[["lay2.bottom"]] - r) < min.thickness] <- NA  # enforce min. thickness
r <- ExcludeSmallCellChunks(r)
names(r) <- "lay3.bottom"
rs.model <- stack(rs.model, r)


## ------------------------------------------------------------------------
r <- rs.model[["lay1.bottom"]]
is.adjusted <- r > rs[["bedrock"]] & is.na(rs.model[["lay2.bottom"]])
r[is.adjusted] <- rs[["bedrock"]][is.adjusted]
r <- ExcludeSmallCellChunks(r)
rs.model[["lay1.bottom"]] <- r


## ------------------------------------------------------------------------
r <- rs[["land.surface"]]
r[is.na(rs.model[["lay1.bottom"]])] <- NA
names(r) <- "lay1.top"
rs.model <- stack(rs.model, r)


## ----echo=FALSE----------------------------------------------------------
r <- rs[["land.surface"]] - rs.model[["lay1.bottom"]]
names(r) <- "lay1.thickness"
rs.model <- stack(rs.model, r)

r <- rs.model[["lay1.bottom"]] - rs.model[["lay2.bottom"]]
names(r) <- "lay2.thickness"
rs.model <- stack(rs.model, r)

r <- rs.model[["lay2.bottom"]] - rs.model[["lay3.bottom"]]
names(r) <- "lay3.thickness"
rs.model <- stack(rs.model, r)


## ------------------------------------------------------------------------
r <- rs.model[["lay1.bottom"]]
r[!is.na(r)] <- 1L  # alluvium cells
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- "Alluvium"
levels(r) <- rat
names(r) <- "lay1.zones"
rs.model <- stack(rs.model, r)


## ----fig_lay1_zones, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Hydrogeologic zones in model layer 1."----
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE, col="#7FC97F",
        rivers=list(x=rivers), lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ------------------------------------------------------------------------
r <- rs.model[["lay2.bottom"]]
r[!is.na(r)] <- 1L  # alluvium cells
r[!is.na(r) & !is.na(rs[["aquitard.extent"]])] <- 3L  # clay cells
r[rs.model[["lay2.bottom"]] < rs[["alluvium.bottom"]]] <- 2L  # basalt cells
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- c("Alluvium", "Basalt", "Clay")
levels(r) <- rat
names(r) <- "lay2.zones"
rs.model <- stack(rs.model, r)


## ----fig_lay2_zones, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Hydrogeologic zones in model layer 2."----
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE,
        col=c("#7FC97F", "#BEAED4", "#FDC086"), rivers=list(x=rivers),
        lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ------------------------------------------------------------------------
r <- rs.model[["lay3.bottom"]]
r[!is.na(r)] <- 1L  # alluvium cells
r[rs.model[["lay3.bottom"]] < rs[["alluvium.bottom"]]] <- 2L  # basalt cells
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- c("Alluvium", "Basalt")
levels(r) <- rat
names(r) <- "lay3.zones"
rs.model <- stack(rs.model, r)


## ----fig_lay3_zones, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Hydrogeologic zones in model layer 3."----
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE,
        col=c("#7FC97F", "#BEAED4"), rivers=list(x=rivers),
        lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ----tbl_vol_flux, echo=FALSE, results="asis"----------------------------
d <- source.lines@data[, c("Name", "Flow")]
d[, 3] <- d[, 2] * 0.296106669
colnames(d) <- c("Name", "Flow (m\\textsuperscript{3}/d)", "(acre-ft/yr)")
tbl <- xtable(d, label="tbl_vol_flux")
caption(tbl) <- "Volumetric flux in the tributary canyons and upper Big Wood River valley."
digits(tbl)[3:4] <- c(0, 0)
print(tbl, include.rownames=FALSE, caption.placement="top", booktabs=TRUE,
      format.args=list(big.mark=","), sanitize.colnames.function=function(x){x})


## ------------------------------------------------------------------------
r <- rs.model[[1]]
r[] <- NA
r.src <- rasterize(source.lines, r)
is.active <- !is.na(rs.model[["lay1.bottom"]][])
r.src[!is.active] <- NA
src.cells <- which(!is.na(r.src[]))
adj.cells <- adjacent(r.src, src.cells, directions = 4)
is.valid.src <- adj.cells[, 2] %in% which(is.active) & !(adj.cells[, 2] %in% src.cells)
rm.src.cells <- src.cells[!(src.cells %in% unique(adj.cells[is.valid.src, 1]))]
rs.model[["lay1.bottom"]][rm.src.cells] <- NA
rs.model[["lay1.top"]][rm.src.cells] <- NA
r.src[rm.src.cells] <- NA
rat <- levels(r.src)[[1]]
for (i in seq_len(nrow(rat))) {
  trib.cells <- which(r.src[] == rat$ID[i])
  r[trib.cells] <- rat$Flow[i] / length(trib.cells)
}
names(r) <- "lay1.bdry.sources"
rs.model <- stack(rs.model, r)


## ------------------------------------------------------------------------
l <- gIntersection(sink.locations, as(aquifer.extent, "SpatialLinesDataFrame"), TRUE)
sink.lines <- SpatialLinesDataFrame(l, data = sink.locations@data, match.ID = FALSE)
r <- rasterize(sink.lines, rs.model, field = "Head")
r[!is.na(r) & is.na(rs.model[["lay1.bottom"]])] <- NA
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- c("Silver Creek", "Staton Crossing")
levels(r) <- rat
names(r) <- "lay1.bdry.sinks"
rs.model <- stack(rs.model, r)
r <- rasterize(sink.lines, rs.model, field = "Head")
r[!is.na(r) & is.na(rs.model[["lay2.bottom"]])] <- NA
names(r) <- "lay2.bdry.sinks"
rs.model <- stack(rs.model, r)
r <- rasterize(sink.lines, rs.model, field = "Head")
r[!is.na(r) & is.na(rs.model[["lay3.bottom"]])] <- NA
names(r) <- "lay3.bdry.sinks"
rs.model <- stack(rs.model, r)


## ----tbl_drain_head, echo=FALSE, results="asis"--------------------------
d <- sink.lines@data[, c("Name", "Head")]
d[, 3] <- d[, 2] * 3.28084
colnames(d) <- c("Name", "Head (m)", "(ft)")
tbl <- xtable(d, label="tbl_drain_head")
caption(tbl) <- "Specified hydraulic head thresholds for sink cell boundary conditions."
digits(tbl)[3:4] <- c(0, 0)
print(tbl, include.rownames=FALSE, caption.placement="top", booktabs=TRUE,
      format.args=list(big.mark=","))


## ----fig_lay1_sinks, echo=FALSE, fig.width=7.50, fig.height=5.83, fig.cap="Location of sink cells in model layer 1."----
r <- rs.model[["lay1.bdry.sinks"]]
PlotMap(r, xlim=s.xlim, ylim=s.ylim, bg.image=img, dms.tick=TRUE,
        col=c("#900E49", "#F2AB05"), rivers=list(x=rivers),
        lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ----echo=FALSE----------------------------------------------------------
nreaches <- nrow(bwr.sc@data)


## ----tbl_river, echo=FALSE, results="asis"-------------------------------
idxs <- order(bwr.sc@data$ReachNo)
d <- bwr.sc@data[idxs, c("Reach", "DrainRiver", "Depth", "BedThk")]
d[, 2] <- tolower(d[, 2])
d[, 5] <- d[, 3] * 3.28084
d[, 6] <- d[, 4] * 3.28084
d <- d[, c(1, 2, 3, 5, 4, 6)]
colnames(d) <- c("Reach name", "Type", "Depth (m)", "(ft)", "Riverbed (m)", "(ft)")
tbl <- xtable(d, label="tbl_river")
caption(tbl) <- "Description of stream reaches in the Big Wood River and Silver Creek."
digits(tbl)[4:7] <- c(1, 0, 1, 0)
print(tbl, include.rownames=FALSE, caption.placement="top", booktabs=TRUE,
      format.args=list(big.mark=","))


## ------------------------------------------------------------------------
r <- rasterize(bwr.sc, rs.model[[1]], field = "ReachNo")
r[is.na(rs.model[["lay1.bottom"]]) | !is.na(rs.model[["lay1.bdry.sinks"]])] <- NA
names(r) <- "riv.reach"
rs.model <- stack(rs.model, r)


## ------------------------------------------------------------------------
r <- rasterize(bwr.sc, rs.model[[1]], field = "DrainRiver")
r[is.na(rs.model[["riv.reach"]])] <- NA
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- c("Drain", "River")
levels(r) <- rat
names(r) <- "riv.bc"
rs.model <- stack(rs.model, r)


## ----fig_river_drain, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Stream-reach types in the Big Wood River and Silver Creek."----
r <- rs.model[["riv.bc"]]
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE,
        col=c("#A80000", "#3399CC"))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ------------------------------------------------------------------------
r.depth <- rasterize(bwr.sc, rs.model[[1]], field = "Depth")
r.riverbed <- rasterize(bwr.sc, rs.model[[1]], field = "BedThk")
r <- rs.model[["lay1.top"]] - r.depth - r.riverbed
r[is.na(rs.model[["riv.reach"]])] <- NA
names(r) <- "riv.bottom"
rs.model <- stack(rs.model, r)


## ----echo=FALSE----------------------------------------------------------
if (any(rs.model[["riv.bottom"]][] < rs.model[["lay1.bottom"]][], na.rm = TRUE))
  warning("Bottom of riverbed sediments is below model layer 1.")


## ------------------------------------------------------------------------
rs.model <- crop(rs.model, trim(rs.model[["lay1.bottom"]]))


## ----tbl_model_str, echo=FALSE, results="asis"---------------------------
nactive <- sum(!is.na(c(rs.model[["lay1.bottom"]][],
                        rs.model[["lay2.bottom"]][],
                        rs.model[["lay3.bottom"]][])))
att <- c("Number of rows", "Number of columns", "Number of layers",
         "Number of active model cells",
         "Uniform x spacing (m)", "Uniform y spacing (m)",
         "World coordinates of model origin x (m)",
         "World coordinates of model origin y (m)")
val <- c(nrow(rs.model), ncol(rs.model), 3, nactive, res(rs.model),
         xmin(rs.model), ymin(rs.model))
d <- as.data.frame(list(Attribute=att, Value=val))
tbl <- xtable(d, label="tbl_model_str")
caption(tbl) <- "Summary description of the model grid attributes."
digits(tbl)[3] <- 0
print(tbl, include.rownames=FALSE, caption.placement="top", booktabs=TRUE,
      format.args=list(big.mark=","))


## ------------------------------------------------------------------------
r <- rs.model[["lay1.bottom"]]
r[] <- as.integer(!is.na(r[]))
names(r) <- "lay1.ibound"
rs.model <- stack(rs.model, r)
r <- rs.model[["lay2.bottom"]]
r[] <-  as.integer(!is.na(r[]))
names(r) <- "lay2.ibound"
rs.model <- stack(rs.model, r)
r <- rs.model[["lay3.bottom"]]
r[] <-  as.integer(!is.na(r[]))
names(r) <- "lay3.ibound"
rs.model <- stack(rs.model, r)


## ------------------------------------------------------------------------
initial.head.frac <- 0.90
r <- rs.model[["lay1.bottom"]] + rs.model[["lay1.thickness"]] * initial.head.frac
names(r) <- "lay1.strt"
rs.model <- stack(rs.model, r)
r <- rs.model[["lay1.strt"]]
r[is.na(rs.model[["lay2.bottom"]])] <- NA
names(r) <- "lay2.strt"
rs.model <- stack(rs.model, r)
r <- rs.model[["lay1.strt"]]
r[is.na(rs.model[["lay3.bottom"]])] <- NA
names(r) <- "lay3.strt"
rs.model <- stack(rs.model, r)


## ------------------------------------------------------------------------
p <- file.path(getwd(), paste0("wrv_", format(Sys.time(), "%Y%m%d%H%M%S")))
dir.create(path = p)
ExportRasterStack(file.path(p, "Data"), rs)
ExportRasterStack(file.path(p, "Model"), rs.model)


## ------------------------------------------------------------------------
id <- "wrv_ss_mfusg"  # identifier for the model run
p.run <- file.path(p, "Run")
CreateModflowInputFiles(rs.model, id, p.run, perlen = 5479, hk = c(30.48, 86.4, 8.64e-7),
                        vani = 1000, cond.riv = 850)


## ----tbl_input_pars, echo=FALSE, results="asis"--------------------------
des <- c("Length of stress period (d)",
         "Horizontal hydraulic conductivity of Alluvium (m/d)",
         "Horizontal hydraulic conductivity of Basalt (m/d)",
         "Horizontal hydraulic conductivity of Clay (m/d)",
         "Global vertical anisotropy",
         "Global conductance of riverbed (m\\textsuperscript{2}/d)")
val <- c("5,479", "30.48", "86.40", "8.64e-07", "1,000", "850")
d <- as.data.frame(list(Parameter=des, Value=val))
tbl <- xtable(d, label="tbl_input_pars", align="llr")
caption(tbl) <- "Input parameters for model run."
print(tbl, include.rownames=FALSE, caption.placement="top", booktabs=TRUE,
      format.args=list(big.mark=","), sanitize.text.function=function(x){x})


## ------------------------------------------------------------------------
cmd <- c(paste("cd", shQuote(p.run)), paste(shQuote(p.exe), shQuote(paste0(id, ".nam"))))
f <- file.path(p.run, "Run.bat")
cat(cmd, file = f, sep = "\n")
Sys.chmod(f, mode = "755")
output <- system(shQuote(f), intern = TRUE)


## ----echo=FALSE----------------------------------------------------------
cat(output[6:length(output)], sep="\n")


## ----tbl_budget, echo=FALSE, results="asis"------------------------------
f <- file.path(p.run, paste0(id, ".lst"))
budgets <- ReadBudgetFromListFile(f)
nbudgets <- length(budgets)
if (nbudgets > 0) {
  b <- budgets[[nbudgets]]
  d <- rbind(b$inputs, NA, b$outputs, NA, b$discrepancy)
  d <- cbind(d, d[, 1] * 0.00081070848625, d[, 2] * 0.296106669)[, c(1, 3, 2, 4)]
  d <- cbind(rownames(d), as.data.frame(d, row.names=seq_len(nrow(d))))
  colnames(d) <- c("", "Volume (m\\textsuperscript{3})", "(acre-ft)",
                   "Rate (m\\textsuperscript{3}/d)", "(acre-ft/yr)")
  tbl <- xtable(d, label="tbl_budget", align="llrrrr", caption=b$caption, digits=0)
  print(tbl, caption.placement="top", format.args=list(big.mark=","),
        booktabs=TRUE, include.rownames=FALSE,
        sanitize.colnames.function=function(x){x})
} else {
  warning("Unable to read volumetric budget.")
}


## ------------------------------------------------------------------------
f <- file.path(p.run, paste0(id, ".hds"))
r <- rs.model[[1]]
rs.heads <- ReadModflowBinaryFile(f, r)


## ------------------------------------------------------------------------
r <- rs.heads[[1]] > rs.model[["lay1.top"]] & rs.heads[[1]] < 1e30
r <- as.factor(r)
rat <- levels(r)[[1]]
rat$att <- c("Partially Saturated", "Saturated")
levels(r) <- rat
names(r) <- "lay1.saturated"
rs.heads <- stack(rs.heads, r)


## ----fig_lay1_sat, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Saturated and partially-saturated cells in model layer 1."----
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE,
        col=c("#91CC9B", "#FF6E61"), rivers=list(x=rivers),
        lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ------------------------------------------------------------------------
is.above.land.surface <- rs.heads[["ts1.sp1.lay1"]] > rs.model[["lay1.top"]]
is.in.lay2 <- rs.heads[["ts1.sp1.lay2"]] > rs.model[["lay2.bottom"]] &
              rs.heads[["ts1.sp1.lay2"]] < rs.model[["lay1.bottom"]]
is.in.lay3 <- rs.heads[["ts1.sp1.lay3"]] < rs.model[["lay2.bottom"]]
r <- rs.heads[["ts1.sp1.lay1"]]
r[is.above.land.surface] <- rs.model[["lay1.top"]][is.above.land.surface]
r[is.in.lay2] <- rs.heads[["ts1.sp1.lay2"]][is.in.lay2]
r[is.in.lay3] <- rs.heads[["ts1.sp1.lay3"]][is.in.lay3]
names(r) <- "water.table"
rs.heads <- stack(rs.heads, r)


## ----fig_water_table, echo=FALSE, fig.width=7.17, fig.height=9.52, fig.cap="Simulated elevation of the water table."----
pal <- colorRampPalette(c("#ABEEF2", "#E2DAAA", "#BAF788"))
hill.shade <- list(z.factor=15, alpha=0.4)
PlotMap(r, xlim=xlim, ylim=ylim, bg.image=img, dms.tick=TRUE, pal=pal,
        explanation="Elevation of simulated water table in meters above NAVD 88.",
        hill.shade=hill.shade, rivers=list(x=rivers), lakes=list(x=lakes))
plot(aquifer.extent, border="#FFFFFF7F", add=TRUE)


## ------------------------------------------------------------------------
ExportRasterStack(p.run, rs.heads)


## ----eval=FALSE----------------------------------------------------------
## browseURL(system.file("doc", "wrv-process.R", package = "wrv"))


## ----echo=FALSE, results="asis"------------------------------------------
print(toLatex(sessionInfo(), locale=FALSE))


## ----echo=FALSE----------------------------------------------------------
ptime <- format(round((proc.time() - ptime)["elapsed"] / 60, digits=0))



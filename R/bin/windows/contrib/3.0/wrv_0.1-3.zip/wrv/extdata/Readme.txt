

u <- "https://github.com/jfisher-usgs/wrv/raw/master/inst/extdata/alluvium.bottom.tif"
alluvium.bottom <- ReadGeoDataFromURL(u)
p4s <- paste("+proj=tmerc +lat_0=42 +lon_0=-114 +k=0.9996 +x_0=2500000",
             "+y_0=1200000 +datum=NAD83 +units=m +no_defs +ellps=GRS80",
             "+towgs84=0,0,0")
proj4string(alluvium.bottom) <- p4s
names(alluvium.bottom) <- "alluvium.bottom"
f <- file.path(getwd(), "data", "alluvium.bottom.rda")
save(alluvium.bottom, file=f)


u <- "https://github.com/jfisher-usgs/wrv/raw/master/inst/extdata/aquifer.extent.zip"
aquifer.extent <- ReadGeoDataFromURL(u)
aquifer.extent <- spTransform(aquifer.extent, alluvium.bottom@proj4string)
f <- file.path(getwd(), "data", "aquifer.extent.rda")
save(aquifer.extent, file=f)


u <- "https://github.com/jfisher-usgs/wrv/raw/master/inst/extdata/aquitard.extent.zip"
aquitard.extent <- ReadGeoDataFromURL(u)
aquitard.extent <- spTransform(aquitard.extent, alluvium.bottom@proj4string)
f <- file.path(getwd(), "data", "aquitard.extent.rda")
save(aquitard.extent, file=f)


u <- "https://github.com/jfisher-usgs/wrv/raw/master/inst/extdata/basalt.extent.zip"
basalt.extent <- ReadGeoDataFromURL(u)
basalt.extent <- spTransform(basalt.extent, alluvium.bottom@proj4string)
f <- file.path(getwd(), "data", "basalt.extent.rda")
save(basalt.extent, file=f)


u <- "https://github.com/jfisher-usgs/wrv/raw/master/inst/extdata/bwr.sc.zip"
bwr.sc <- ReadGeoDataFromURL(u)
bwr.sc <- spTransform(bwr.sc, alluvium.bottom@proj4string)
f <- file.path(getwd(), "data", "bwr.sc.rda")
save(bwr.sc, file=f)


u <- "https://github.com/jfisher-usgs/wrv/raw/master/inst/extdata/cities.zip"
cities <- ReadGeoDataFromURL(u)
cities <- spTransform(cities, alluvium.bottom@proj4string)
f <- file.path(getwd(), "data", "cities.rda")
save(cities, file=f)


u <- "https://github.com/jfisher-usgs/wrv/raw/master/inst/extdata/lakes.zip"
lakes <- ReadGeoDataFromURL(u)
lakes <- spTransform(lakes, alluvium.bottom@proj4string)
f <- file.path(getwd(), "data", "lakes.rda")
save(lakes, file=f)


f <- "C:/n44w115/grdn44w115_13"
r <- raster(readGDAL(f, band=1L))
r <- projectRaster(r, raster(alluvium.bottom), method="bilinear")
r[is.na(raster(alluvium.bottom))] <- NA
land.surface <- as(r, "SpatialGridDataFrame")
names(land.surface) <- "land.surface"
f <- file.path(getwd(), "data", "land.surface.rda")
save(land.surface, file=f)


f <- file.path(getwd(), "inst", "extdata", "map.labels.csv")
map.labels <- read.csv(f, strip.white=TRUE, stringsAsFactors=FALSE)
map.labels$label <- sub("\\\\n", "\\\n", map.labels$label)
coordinates(map.labels) <- 1:2
colnames(map.labels@coords) <- c("x", "y")
proj4string(map.labels) <- CRS("+init=epsg:4326")
map.labels <- spTransform(map.labels, alluvium.bottom@proj4string)
f <- file.path(getwd(), "data", "map.labels.rda")
save(map.labels, file=f)


u <- "https://github.com/jfisher-usgs/wrv/raw/master/inst/extdata/rivers.zip"
rivers <- ReadGeoDataFromURL(u)
rivers <- spTransform(rivers, alluvium.bottom@proj4string)
f <- file.path(getwd(), "data", "rivers.rda")
save(rivers, file=f)


f <- file.path(getwd(), "inst", "extdata", "sink.locations.kml")
sink.locations <- readOGR(f, basename(f))
sink.locations <- spTransform(sink.locations, alluvium.bottom@proj4string)
f <- file.path(getwd(), "inst", "extdata", "sink.locations.csv")
h <- read.csv(f, row.names=1L)
sink.locations@data <- cbind(sink.locations@data, h)
f <- file.path(getwd(), "data", "sink.locations.rda")
save(sink.locations, file=f)


f <- file.path(getwd(), "inst", "extdata", "source.locations.kml")
source.locations <- readOGR(f, basename(f))
source.locations <- spTransform(source.locations, alluvium.bottom@proj4string)
f <- file.path(getwd(), "inst", "extdata", "source.locations.csv")
h <- read.csv(f, row.names=1L)
source.locations@data <- cbind(source.locations@data, h)
f <- file.path(getwd(), "data", "source.locations.rda")
save(source.locations, file=f)


f <- "C:/n44w115/grdn44w115_13"
r <- raster(readGDAL(f, band=1L))
ab <- raster(alluvium.bottom)
ext <- extent(ab)
ext <- extent(c(extendrange(c(ext@xmin, ext@xmax), f=0.05),
                extendrange(c(ext@ymin, ext@ymax), f=0.05)))
ab <- extend(ab, ext)
r <- projectRaster(r, ab, method="bilinear")
r <- r * 2.0
r <- hillShade(slope=terrain(r), aspect=terrain(r, opt="aspect"), angle=45,
               direction=0)
f <- file.path(getwd(), "inst", "extdata", "hillshade.png")
r.ran <- range(values(r), na.rm=TRUE)
values(r) <- findInterval(values(r), seq(r.ran[1], r.ran[2], length.out=255)) / 255
png::writePNG(as.matrix(r), target=f, asp=1, text=c(projargs=proj4string(r)),
              metadata=c(xleft=ext@xmin, ybottom=ext@ymin, xright=ext@xmax,
                         ytop=ext@ymax))

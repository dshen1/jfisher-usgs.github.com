
## ----setup, include=FALSE, cache=FALSE-----------------------------------
knitr::opts_chunk$set(dev="pdf", tidy=FALSE)
options(warn=1)
options(width=90)
ptime <- proc.time()


## ----eval=FALSE----------------------------------------------------------
## install.packages(c("NADA", "rgdal"), repos = "http://cran.rstudio.com/")
## install.packages("Trends", repos = "http://jfisher-usgs.github.com/R/")


## ------------------------------------------------------------------------
library(Trends)


## ------------------------------------------------------------------------
merge.pdfs <- as.logical(nchar(Sys.which("pdftk")))
print(merge.pdfs)


## ------------------------------------------------------------------------
path.in <- system.file("extdata", "SIR2014", package = "Trends")
list.files(path.in)


## ------------------------------------------------------------------------
path.out <- file.path(getwd(), paste0("Trends_", format(Sys.time(), "%Y%m%d%H%M%S")))
dir.create(path = path.out, showWarnings = FALSE)


## ------------------------------------------------------------------------
gr.type <- "pdf"


## ------------------------------------------------------------------------
d <- ReadObservations(file.path(path.in, "Data.tsv"))


## ------------------------------------------------------------------------
par.config <- ReadParConfig(file.path(path.in, "Config_Par.tsv"))


## ------------------------------------------------------------------------
site.locs <- ReadSiteLocations(path.in, layer = "Site_Locations", verbose = FALSE)


## ------------------------------------------------------------------------
plot.config <- ReadPlotConfig(file.path(path.in, "Config_Plots.tsv"))
PlotObservations(d, par.config = par.config, plot.config = plot.config,
                 sdate = "01/01/1960", edate = "01/01/2013", gr.type = gr.type,
                 path.out = file.path(path.out, "Data_1960-2012"),
                 merge.pdfs = merge.pdfs)


## ------------------------------------------------------------------------
PlotObservations(d, par.config = par.config, plot.config = plot.config,
                 sdate = "01/01/1989", edate = "01/01/2013", gr.type = gr.type,
                 path.out = file.path(path.out, "Data_1989-2012"),
                 merge.pdfs = merge.pdfs)


## ------------------------------------------------------------------------
plot.config <- ReadPlotConfig(file.path(path.in, "Config_Plots_Field.tsv"))
PlotObservations(d, par.config = par.config, plot.config = plot.config,
                 sdate = "01/01/1960", edate = "01/01/2013", gr.type = gr.type,
                 path.out = file.path(path.out, "Data_1960-2012_Field"),
                 merge.pdfs = merge.pdfs)


## ------------------------------------------------------------------------
PlotObservations(d, par.config = par.config, plot.config = plot.config,
                 sdate = "01/01/1989", edate = "01/01/2013", gr.type = gr.type,
                 path.out = file.path(path.out, "Data_1989-2012_Field"),
                 merge.pdfs = merge.pdfs)


## ------------------------------------------------------------------------
plot.config <- ReadPlotConfig(file.path(path.in, "Config_Cen.tsv"))
out <- RunTrendAnalysis(d, par.config = par.config, plot.config = plot.config,
                        sdate = "01/01/1989", edate = "01/01/2013", is.censored = TRUE,
                        path.out = file.path(path.out, "Stats_1989-2012_Cen"),
                        gr.type = gr.type, site.locs = site.locs, merge.pdfs = merge.pdfs)


## ------------------------------------------------------------------------
plot.config <- ReadPlotConfig(file.path(path.in, "Config_Uncen.tsv"))
out <- RunTrendAnalysis(d, par.config=par.config, plot.config=plot.config,
                        sdate = "01/01/1960", edate = "01/01/2013", is.censored = FALSE,
                        path.out = file.path(path.out, "Stats_1960-2012_Uncen"),
                        gr.type = gr.type, site.locs = site.locs, merge.pdfs = merge.pdfs)


## ------------------------------------------------------------------------
out <- RunTrendAnalysis(d, par.config = par.config, plot.config = plot.config,
                        sdate = "01/01/1989", edate = "01/01/2013", is.censored = FALSE,
                        path.out = file.path(path.out, "Stats_1989-2012_Uncen"),
                        gr.type = gr.type, site.locs = site.locs, merge.pdfs = merge.pdfs)


## ------------------------------------------------------------------------
plot.config <- ReadPlotConfig(file.path(path.in, "Config_Uncen_Field.tsv"))
out <- RunTrendAnalysis(d, par.config = par.config, plot.config = plot.config,
                        sdate = "01/01/1960", edate = "01/01/2013", is.censored = FALSE,
                        path.out = file.path(path.out, "Stats_1960-2012_Uncen_Field"),
                        gr.type = gr.type, site.locs = site.locs, merge.pdfs = merge.pdfs)


## ------------------------------------------------------------------------
out <- RunTrendAnalysis(d, par.config = par.config, plot.config = plot.config,
                        sdate = "01/01/1989", edate = "01/01/2013", is.censored = FALSE,
                        path.out = file.path(path.out, "Stats_1989-2012_Uncen_Field"),
                        gr.type = gr.type, site.locs = site.locs, merge.pdfs = merge.pdfs)


## ----echo=FALSE----------------------------------------------------------
ptime <- format(round((proc.time() - ptime)["elapsed"] / 60, digits=0))


## ----echo=FALSE, results="asis"------------------------------------------
print(toLatex(sessionInfo(), locale=FALSE))



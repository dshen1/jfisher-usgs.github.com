
## ----setup, include=FALSE, cache=FALSE-----------------------------------
ptime <- proc.time()
try(knitr::opts_chunk$set(dev="pdf", tidy=FALSE, comment="#",
                          fig.align="center"), silent=TRUE)
sp::set_ReplCRS_warn(FALSE)
msg <- "object not equal to wrv-package data set"


## ----message=FALSE-------------------------------------------------------
library(rgdal)   # bindings for the geospatial data abstraction library
library(raster)  # gridded spatial data toolkit
library(RCurl)   # general network client interface
library(png)     # read and write png images


## ------------------------------------------------------------------------
url <- "https://github.com/jfisher-usgs/wrv/raw/master/inst/extdata/"


## ------------------------------------------------------------------------
file.ned <- "C:/n44w115/grdn44w115_13"


## ------------------------------------------------------------------------
dir.data <- file.path(getwd(), "data")
dir.extdata <- file.path(getwd(), "inst", "extdata")
dir.create(dir.data, showWarnings = FALSE)
dir.create(dir.extdata, showWarnings = FALSE, recursive = TRUE)


## ------------------------------------------------------------------------
crs <- CRS(paste("+proj=tmerc +lat_0=42 +lon_0=-114 +k=0.9996 +x_0=2500000 +y_0=1200000",
                 "+datum=NAD83 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0"))


## ----eval=TRUE, echo=-7--------------------------------------------------
files <- wrv::DownloadFile(paste0(url, "cities.zip"))
layer <- sub(".shp$", "", basename(files[grep("*.shp$", files)]))
cities <- readOGR(dsn = tempdir(), layer = layer, verbose = FALSE)
cities <- spTransform(cities, crs)
save(cities, file = file.path(dir.data, "cities.rda"))
unlink(files)
if (!identical(cities, wrv::cities)) warning(msg)


## ----cities, echo=FALSE, fig.cap="Cities and towns in the Wood River Valley and surrounding areas."----
par(mai=c(0, 0, 0, 0))
plot(cities, pch=15, cex=0.8, col="#333333")
text(cities, labels=cities@data$CITY_NAME, col="#333333", cex=0.5, pos=1, offset=0.4)


## ----eval=TRUE, echo=-10-------------------------------------------------
file <- wrv::DownloadFile(paste0(url, "map.labels.csv"))
map.labels <- read.csv(file, strip.white=TRUE, stringsAsFactors = FALSE)
map.labels$label <- sub("\\\\n", "\\\n", map.labels$label)
coordinates(map.labels) <- 1:2
colnames(map.labels@coords) <- c("x", "y")
proj4string(map.labels) <- CRS("+init=epsg:4326")
map.labels <- spTransform(map.labels, crs)
save(map.labels, file = file.path(dir.data, "map.labels.rda"))
unlink(file)
if (!identical(map.labels, wrv::map.labels)) warning(msg)


## ----map_labels, echo=FALSE, fig.cap="Map labels in the Wood River Valley and surrounding areas."----
par(mai=c(0, 0, 0, 0))
plot(NA, xlim=bbox(map.labels)[1, ], ylim=bbox(map.labels)[2, ], asp=1, axes=FALSE)
lab <- cbind(map.labels@coords, map.labels@data)
for (i in seq_len(nrow(lab))) {
  text(lab$x[i], lab$y[i], labels=lab$label[i], cex=lab$cex[i], col=lab$col[i],
       font=lab$font[i], srt=lab$srt[i])
}


## ----eval=TRUE, echo=-7--------------------------------------------------
files <- wrv::DownloadFile(paste0(url, "bwr.sc.zip"))
layer <- sub(".shp$", "", basename(files[grep("*.shp$", files)]))
bwr.sc <- readOGR(dsn = tempdir(), layer = layer, verbose = FALSE)
bwr.sc <- spTransform(bwr.sc, crs)
save(bwr.sc, file = file.path(dir.data, "bwr.sc.rda"))
unlink(files)
if (!identical(bwr.sc, wrv::bwr.sc)) warning(msg)


## ----bwr_sc, echo=FALSE, fig.cap="Reaches of the Big Wood River and Silver Creek."----
par(mai=c(0, 0, 0, 0))
obj <- bwr.sc
obj$Reach1 <- factor(obj$Reach, levels=levels(obj$Reach)[order(obj$ReachNo, decreasing=TRUE)])
spplot(obj, "Reach1", col.regions=rev(topo.colors(nlevels(obj@data$Reach1))),
       par.settings=list(axis.line=list(col="transparent"), fontsize=list(text=10)))


## ----eval=TRUE, echo=-7--------------------------------------------------
files <- wrv::DownloadFile(paste0(url, "rivers.zip"))
layer <- sub(".shp$", "", basename(files[grep("*.shp$", files)]))
rivers <- readOGR(dsn = tempdir(), layer = layer, verbose = FALSE)
rivers <- spTransform(rivers, crs)
save(rivers, file = file.path(dir.data, "rivers.rda"))
unlink(files)
if (!identical(rivers, wrv::rivers)) warning(msg)


## ----rivers, echo=FALSE, fig.cap="Rivers and streams of the Wood River Valley and surrounding areas."----
par(mai=c(0, 0, 0, 0))
plot(rivers, col="#3399CC")


## ----eval=TRUE, echo=-7--------------------------------------------------
files <- wrv::DownloadFile(paste0(url, "lakes.zip"))
layer <- sub(".shp$", "", basename(files[grep("*.shp$", files)]))
lakes <- readOGR(dsn = tempdir(), layer = layer, verbose = FALSE)
lakes <- spTransform(lakes, crs)
save(lakes, file = file.path(dir.data, "lakes.rda"))
unlink(files)
if (!identical(lakes, wrv::lakes)) warning(msg)


## ----lakes, echo=FALSE, fig.cap="Lakes and reservoirs of the Wood River Valley and surrounding areas."----
par(mai=c(0, 0, 0, 0))
plot(lakes, col="#CCFFFF", border="#3399CC", lwd=0.5)


## ----eval=TRUE, echo=-7--------------------------------------------------
files <- wrv::DownloadFile(paste0(url, "aquifer.extent.zip"))
layer <- sub(".shp$", "", basename(files[grep("*.shp$", files)]))
aquifer.extent <- readOGR(dsn = tempdir(), layer = layer, verbose = FALSE)
aquifer.extent <- spTransform(aquifer.extent, crs)
save(aquifer.extent, file = file.path(dir.data, "aquifer.extent.rda"))
unlink(files)
if (!identical(aquifer.extent, wrv::aquifer.extent)) warning(msg)


## ----aquifer_extent, echo=FALSE, fig.cap="Estimated extent of the Wood River Valley aquifer system."----
par(mai=c(0, 0, 0, 0))
plot(aquifer.extent, col="#BFA76F")


## ----eval=TRUE, echo=-7--------------------------------------------------
files <- wrv::DownloadFile(paste0(url, "aquitard.extent.zip"))
layer <- sub(".shp$", "", basename(files[grep("*.shp$", files)]))
aquitard.extent <- readOGR(dsn = tempdir(), layer = layer, verbose = FALSE)
aquitard.extent <- spTransform(aquitard.extent, crs)
save(aquitard.extent, file = file.path(dir.data, "aquitard.extent.rda"))
unlink(files)
if (!identical(aquitard.extent, wrv::aquitard.extent)) warning(msg)


## ----aquitard_extent, echo=FALSE, fig.height=3, fig.cap="Estimated extent of the confining unit separating the unconfined aquifer from the underlying confined aquifer in the Wood River Valley."----
par(mai=c(0, 0, 0, 0))
plot(aquitard.extent, col="#FDC086")


## ----eval=TRUE, echo=-7--------------------------------------------------
files <- wrv::DownloadFile(paste0(url, "basalt.extent.zip"))
layer <- sub(".shp$", "", basename(files[grep("*.shp$", files)]))
basalt.extent <- readOGR(dsn = tempdir(), layer = layer, verbose = FALSE)
basalt.extent <- spTransform(basalt.extent, crs)
save(basalt.extent, file = file.path(dir.data, "basalt.extent.rda"))
unlink(files)
if (!identical(basalt.extent, wrv::basalt.extent)) warning(msg)


## ----basalt_extent, echo=FALSE, fig.height=3, fig.cap="Estimated extent of the basalt underlying the alluvial Wood River Valley aquifer system."----
par(mai=c(0, 0, 0, 0))
plot(basalt.extent, col="#BEAED4")


## ----eval=TRUE, echo=-10-------------------------------------------------
file <- wrv::DownloadFile(paste0(url, "source.locations.kml"))
source.locations <- suppressWarnings(readOGR(file, basename(file), verbose = FALSE))
source.locations <- spTransform(source.locations, crs)
unlink(file)
file <- wrv::DownloadFile(paste0(url, "source.locations.csv"))
h <- read.csv(file, row.names = 1)
source.locations@data <- cbind(source.locations@data, h)
save(source.locations, file = file.path(dir.data, "source.locations.rda"))
unlink(file)
if (!identical(source.locations, wrv::source.locations)) warning(msg)


## ----source_locations, echo=FALSE, fig.cap="Polygons used to define boundary conditions at source locations in the model domain."----
par(mai=c(0, 0, 0, 0))
spplot(source.locations, "Name", col.regions=rainbow(nlevels(source.locations@data$Name)),
       par.settings=list(axis.line=list(col="transparent"), fontsize=list(text=10)))


## ----eval=TRUE, echo=-10-------------------------------------------------
file <- wrv::DownloadFile(paste0(url, "sink.locations.kml"))
sink.locations <- suppressWarnings(readOGR(file, basename(file), verbose = FALSE))
sink.locations <- spTransform(sink.locations, crs)
unlink(file)
file <- wrv::DownloadFile(paste0(url, "sink.locations.csv"))
h <- read.csv(file, row.names = 1)
sink.locations@data <- cbind(sink.locations@data, h)
save(sink.locations, file = file.path(dir.data, "sink.locations.rda"))
unlink(file)
if (!identical(sink.locations, wrv::sink.locations)) warning(msg)


## ----sink_locations, echo=FALSE, fig.height=1.2, fig.cap="Polygons used to define boundary conditions at sink locations in the model domain."----
par(mai=c(0, 0, 0, 0))
spplot(sink.locations, "Name", col.regions=c("#900E49", "#F2AB05"),
       ylim=extendrange(bbox(sink.locations)[2, ], f=2),
       par.settings=list(axis.line=list(col="transparent"), fontsize=list(text=10),
       layout.heights=list(top.padding=-20, bottom.padding=-20)))


## ----eval=TRUE, echo=-7--------------------------------------------------
file <- wrv::DownloadFile(paste0(url, "alluvium.bottom.tif"))
alluvium.bottom <- readGDAL(file, band = 1, silent = TRUE)
proj4string(alluvium.bottom) <- crs
names(alluvium.bottom) <- "alluvium.bottom"
save(alluvium.bottom, file = file.path(dir.data, "alluvium.bottom.rda"))
unlink(file)
if (!identical(alluvium.bottom, wrv::alluvium.bottom)) warning(msg)


## ----alluvium_bottom, echo=FALSE, fig.cap="Estimated elevation of the pre-Quaternary bedrock surface and top of Quaternary basalt in the the Wood River Valley aquifer system."----
par(mai=c(0, 0, 0, 0))
image(raster(alluvium.bottom), useRaster=TRUE, col=rainbow(255), asp=1, axes=FALSE)


## ----eval=TRUE, echo=c(-3, -8)-------------------------------------------
r <- raster(readGDAL(file.ned, band = 1, silent = TRUE))
r <- projectRaster(r, raster(alluvium.bottom), method = "bilinear")
obj <- r
r[is.na(raster(alluvium.bottom))] <- NA
land.surface <- as(r, "SpatialGridDataFrame")
names(land.surface) <- "land.surface"
save(land.surface, file = file.path(dir.data, "land.surface.rda"))
if (!identical(land.surface, wrv::land.surface)) warning(msg)


## ----land_surface, echo=FALSE, fig.cap="Topography of the land surface in the Wood River Valley and vicinity."----
par(mai=c(0, 0, 0, 0))
image(obj, useRaster=TRUE, col=terrain.colors(255), asp=1, axes=FALSE)


## ----eval=TRUE-----------------------------------------------------------
r <- raster(readGDAL(file.ned, band = 1, silent = TRUE))
ext <- extent(raster(alluvium.bottom))
xext <- extendrange(c(ext@xmin, ext@xmax), f = 0.05)
yext <- extendrange(c(ext@ymin, ext@ymax), f = 0.05)
ext <- extent(c(xext, yext))
r <- projectRaster(r, extend(raster(alluvium.bottom), ext), method = "bilinear")
r[] <- r[] * 2
aspect <- terrain(r, opt = "aspect")
r <- hillShade(slope = terrain(r), aspect = aspect, angle = 45, direction = 0)
r.range <- range(r[], na.rm = TRUE)
r[] <- findInterval(r[], seq(r.range[1], r.range[2], length.out = 255)) / 255
text <- c(projargs = proj4string(r))
metadata <- c(xleft = ext@xmin, ybottom = ext@ymin, xright = ext@xmax, ytop = ext@ymax)
file <- file.path(dir.extdata, "hillshade.png")
writePNG(as.matrix(r), target = file, asp = 1, text = text, metadata = metadata)


## ----hillshade, echo=FALSE, fig.cap="Hillshading based on the slope and aspect of land-surface elevations."----
par(mai=c(0, 0, 0, 0))
image(r, length(r), useRaster=TRUE, col=grey(0:255 / 255), asp=1, axes=F)


## ----eval=FALSE----------------------------------------------------------
## source(system.file("doc", "wrv-datasets.R", package = "wrv"), echo = TRUE)
## list.files(c(dir.data, dir.extdata), full.names = TRUE)  # path names of output files


## ----echo=FALSE, results="asis"------------------------------------------
print(toLatex(sessionInfo(), locale=FALSE))


